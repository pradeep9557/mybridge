<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of employee
 *
 * @author Mr. Anup
 */
class employee_model extends CI_Model {

    //put your code here
    function __construct() {
        parent::__construct();
    }

    function form_validation($POST) {
        $err_codes = '';
        if (isset($POST['Emp_Code']) && $POST['Emp_Code'] == "") {
            $err_codes.='E_CodeBlank' . ERR_DELIMETER;
        }
        if (isset($POST['Emp_Name']) && $POST['Emp_Name'] == "") {
            $err_codes.='E_NameBlank' . ERR_DELIMETER;
        }
        if (isset($POST['UserName']) && $POST['UserName'] == "") {
            $err_codes.='E_UserNameBlank' . ERR_DELIMETER;
        }
        $valid = $err_codes == '' ? TRUE : FALSE;
        return array("_err" => $valid, "_err_codes" => $err_codes);
    }

    function employee_save_update($employee_form_data) {
        //($this->util_model->printr($employee_form_data));
        $validates = $this->form_validation($employee_form_data); // validating the form
        // die($this->util_model->printr($validates));
        if ($validates['_err_codes']!="") {
            return array("succ" => false, "_err_codes" => $validates['_err_codes']);
        }
        $this->load->model("upload/file_upload");
        $this->load->helper('file');
        if ($employee_form_data["Add_Employee"] === "Save") {
            $pro_pic = $_FILES['Pro_Pic']['name'];
            $sign = $_FILES['Sign']['name'];
            $Emp_Code = strtoupper($employee_form_data['Emp_Code']);
            if ($pro_pic != "") {
                if (file_exists(EMP_UPLOAD_PATH . $pro_pic)) {
                    unlink(EMP_UPLOAD_PATH . $pro_pic);
                }
                if (move_uploaded_file($_FILES['Pro_Pic']['tmp_name'], EMP_UPLOAD_PATH . $pro_pic)) {
                    $this->file_upload->initial(EMP_UPLOAD_PATH . $pro_pic);
                    $this->file_upload->resizeImage(330, 426, 'auto');
                    if (file_exists(EMP_UPLOAD_PATH . $Emp_Code . "Pro_Pic.gif")) {
                        unlink(EMP_UPLOAD_PATH . $Emp_Code . "Pro_Pic.gif");
                    }
                    $this->file_upload->saveImage(EMP_UPLOAD_PATH . $Emp_Code . "Pro_Pic.gif", 100);
                    unlink(EMP_UPLOAD_PATH . $pro_pic);
                }
            }
            if ($sign != "") {
                if (file_exists(EMP_UPLOAD_PATH . $sign)) {
                    unlink(EMP_UPLOAD_PATH . $sign);
                }
                if (move_uploaded_file($_FILES['Sign']['tmp_name'], EMP_UPLOAD_PATH . $sign)) {
                    $this->file_upload->initial(EMP_UPLOAD_PATH . $sign);
                    $this->file_upload->resizeImage(330, 426, 'auto');
                    if (file_exists(EMP_UPLOAD_PATH . $Emp_Code . "Sign.gif")) {
                        unlink(EMP_UPLOAD_PATH . $Emp_Code . "Sign.gif");
                    }
                    $this->file_upload->saveImage(EMP_UPLOAD_PATH . $Emp_Code . "Sign.gif", 100);
                    unlink(EMP_UPLOAD_PATH . $sign);
                }
            }
            $employee_form_data['Pro_Pic'] = $Emp_Code . "Pro_Pic.gif";
            $employee_form_data['Sign'] = $Emp_Code . "Sign.gif";
            
            $data_to_insert = $this->util_model->unset_array($employee_form_data, array('Add_Employee', 'Password', 'send_on_mail', 'confirmPassword', 'Working_Days', 'Str_Time', 'End_Time'));
            $data_to_insert = $this->util_model->add_common_fields($data_to_insert);
            
            $employee_form_data['Quali'] = isset($employee_form_data['Quali'])?$employee_form_data['Quali']:array();
            $data_to_insert['Quali'] = serialize($employee_form_data['Quali']);
           // die($this->util_model->printr($data_to_insert));
            // menual transaction started
            $this->db->trans_begin();
            $this->db->insert(DB_PREFIX . "employee", $data_to_insert);
            
            if ($this->db->trans_status() === TRUE) {
                $this->db->trans_commit();
                return array("succ" => TRUE, "_err_codes" => "Emp_AddSucc");
            } else {
                $this->db->trans_rollback();
                return array("succ" => FALSE, "_err_codes" => "Emp_AddErr".ERR_DELIMETER);
            }
        } else if ($employee_form_data["Add_Employee"] === "Update") {
            $pro_pic = $_FILES['Pro_Pic']['name'];
            $sign = $_FILES['Sign']['name'];
            $Emp_Code = strtoupper($employee_form_data['Emp_Code']);
            $old_emp_code = $employee_form_data['Old_Emp_Code'];
            $old_emp_details = $this->get_details_from_database($old_emp_code);
            //print_r($old_emp_details);
            $old_Pro_Pic = $old_emp_details->Pro_Pic;
            $old_Sign = $old_emp_details->Sign;
            if ($pro_pic != "") {
                if (file_exists(EMP_UPLOAD_PATH . $old_Pro_Pic)) {
                    unlink(EMP_UPLOAD_PATH . $old_Pro_Pic);
                }
                if (move_uploaded_file($_FILES['Pro_Pic']['tmp_name'], EMP_UPLOAD_PATH . $pro_pic)) {
                    $this->file_upload->initial(EMP_UPLOAD_PATH . $pro_pic);
                    $this->file_upload->resizeImage(330, 426, 'auto');
                    if (file_exists(EMP_UPLOAD_PATH . $Emp_Code . "Pro_Pic.gif")) {
                        unlink(EMP_UPLOAD_PATH . $Emp_Code . "Pro_Pic.gif");
                    }
                    $this->file_upload->saveImage(EMP_UPLOAD_PATH . $Emp_Code . "Pro_Pic.gif", 100);
                    unlink(EMP_UPLOAD_PATH . $pro_pic);
                }
            }
            if ($sign != "") {
                if (file_exists(EMP_UPLOAD_PATH . $old_Sign)) {
                    unlink(EMP_UPLOAD_PATH . $old_Sign);
                }
                if (move_uploaded_file($_FILES['Sign']['tmp_name'], EMP_UPLOAD_PATH . $sign)) {
                    $this->file_upload->initial(EMP_UPLOAD_PATH . $sign);
                    $this->file_upload->resizeImage(330, 426, 'auto');
                    if (file_exists(EMP_UPLOAD_PATH . $Emp_Code . "Sign.gif")) {
                        unlink(EMP_UPLOAD_PATH . $Emp_Code . "Sign.gif");
                    }
                    $this->file_upload->saveImage(EMP_UPLOAD_PATH . $Emp_Code . "Sign.gif", 100);
                    unlink(EMP_UPLOAD_PATH . $sign);
                }
            }
            $employee_form_data['Pro_Pic'] = $Emp_Code . "Pro_Pic.gif";
            $employee_form_data['Sign'] = $Emp_Code . "Sign.gif";
            $data_to_update = $this->employee_query_string($employee_form_data);
            if ($this->db->update('nexgen_employee', $data_to_update, array('Emp_Code' => $old_emp_code))) {
                return array(TRUE, array("Emp_Code" => $Emp_Code, "Emp_Name" => $data_to_insert['Emp_Name'], "P_Email" => $data_to_insert['P_Email']));
            } else {
                return array(FALSE, $data_to_insert);
            }
        }
    }

    public function update_emp($Emp_Code, $data_to_update) {
        if ($this->db->update('nexgen_employee', $data_to_update, array('Emp_Code' => $Emp_Code))) {
            return TRUE;
        } else {
            return FALSE;
        }
    }

  

    public function auth_details($user_data) {
        $sql = "SELECT * FROM `" . DB_PREFIX . "employee` WHERE  (`Emp_Code`='{$user_data['Emp_Code']}' or `UserName`='{$user_data['Emp_Code']}' or `P_Email`='{$user_data['Emp_Code']}') and `UTID`={$user_data['Type']} and `Status`=1";
        $query = $this->db->query($sql);
        $result = $query->result();
        if (count($result) > 0) {
            if ($user_data['Password'] == $this->util_model->decrypt_string($result[0]->Emp_Pass))
                return array("succ" => TRUE, "emp_details" => $result[0]);
        }else {
            return array("succ" => FALSE);
        }

//emp_details
    }

    public function get_emp_details_from_database($Emp_Code = '',$UTID=0,$DID=0) {
        $Emp_Code = trim($Emp_Code);
        $where = array();
        if($Emp_Code!='')
          $where['emp.Emp_Code'] =$Emp_Code;
        if($UTID!=0){
            $where['emp.UTID'] = $UTID;
        }
        if($DID!=0){
            $where['emp.DID'] = $DID;
        }
        $this->db->select("emp.*,`t3`.`Emp_Code` as Add_UserCode,d.Name as Designation, n.Name as Nationality  from ".DB_PREFIX."employee emp");
        $this->db->join(DB_PREFIX . "employee t3", "emp.Add_User=t3.Emp_ID", 'LEFT');
        $this->db->join(DB_PREFIX . "designation d", "emp.DID=d.DID", 'LEFT');
        $this->db->join(DB_PREFIX . "nationality n", "emp.NID=n.NID", 'LEFT');
        $this->db->where($where);
        $query = $this->db->get();
            if ($this->db->count_all_results() > 0) {
                 if($Emp_Code!=''){
                $emp_details = $query->first_row();
                return $emp_details; //sending first row
                 }else{
                     return $query->result();
                 }
            } else {
                return FALSE;
            }
//        $Emp_Code = trim($Emp_Code);
//        if (!$only_faculty) {
//            $DesgType = $this->input->post('Type');
//            $query = $this->db->get_where('nexgen_employee', array("Emp_Code" => $Emp_Code, "DID" => $DesgType));
//            if ($this->db->count_all_results() > 0) {
//                $emp_details = $query->first_row();
//                return $emp_details; //sending first row
//            } else {
//                return FALSE;
//            }
//        } else {
//            $query = $this->db->get_where('nexgen_employee', array("Designation" => "Faculty"));
//            $result = $query->result();
//            $Emp_list_with_Emp_Cat = array("<-- Select Faculty Code -->" => "<-- Select Faculty Code -->");
//            foreach ($result as $value) {
//                $Emp_list_with_Emp_Cat[$value->Emp_Code] = $value->Emp_Code;
//            }
//            return $Emp_list_with_Emp_Cat;
//        }
    }
    public function get_emp_details_via_emp_id($Emp_ID){
        $query = $this->db->get_where(DB_PREFIX.'employee', array("Emp_ID"=>$Emp_ID));
        $result = $query->result();
        if(!empty($result))
        return $result[0];
        else
            return FALSE;
    }
    public function get_all_details_from_database() {
        $query = $this->db->select('emp.*')->from(DB_PREFIX."employee emp");
        $this->db->join(DB_PREFIX . "employee t3", "emp.Add_User=t3.Emp_ID", 'LEFT');
        $all_emp_details = $query->result();
        return $all_emp_details; //sending first row
    }

}
