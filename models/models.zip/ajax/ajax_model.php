<?php

class ajax_model extends CI_Model {

              function __construct() {
                            parent::__construct();
              }

              public function upload_pic($path, $Uploading_Pic_Name, $FILE) {
                            $this->load->helper('file');
                            //$this->load->helper('url');
                            $this->load->model("upload/file_upload");
                            $PIC = $FILE['name'];
                            if ($PIC != "") {
                                          if (file_exists($path . $PIC)) {
                                                        unlink($path . $PIC);
                                          }
                                          if (move_uploaded_file($FILE['tmp_name'], $path . $PIC)) {
                                                        $this->file_upload->initial($path . $PIC);

                                                        $this->file_upload->resizeImage(330, 426, 'auto');
                                                        if (file_exists($path . $Uploading_Pic_Name)) {
                                                                      unlink($path . $Uploading_Pic_Name);
                                                        }
                                                        $this->file_upload->saveImage($path . $Uploading_Pic_Name, 100);
                                                        unlink($path . $PIC);
                                          }
                            }
                            return array(TRUE, $Uploading_Pic_Name);
              }

              public function Search_Student($Searching_Form_Data) {
                            $query = "";

                            if ($Searching_Form_Data['Searching_option'] === "EnrollNo") {
                                          $this->db->select(DB_PREFIX . 'scnb.EnrollNo,' . DB_PREFIX . 'stu_mst.DOR,' . DB_PREFIX . 'stu_mst.Stu_ID,' . DB_PREFIX . 'stu_mst.StudentName,' . DB_PREFIX . 'stu_mst.FatherName,' . DB_PREFIX . 'scnb.CourseCode,' . DB_PREFIX . 'stu_mst.Mobile1,' . DB_PREFIX . 'scnb.Add_User,' . DB_PREFIX . 'scnb.Mode_User');
                                          $this->db->from('' . DB_PREFIX . 'stu_mst');
                                          $this->db->join('' . DB_PREFIX . 'scnb', '' . DB_PREFIX . 'scnb.EnrollNo = ' . DB_PREFIX . 'stu_mst.EnrollNo', 'inner')->where(array('' . DB_PREFIX . 'stu_mst.EnrollNo' => $Searching_Form_Data['EnrollNo'], '' . DB_PREFIX . 'scnb.EnrollNo' => $Searching_Form_Data['EnrollNo']));
                                          $query = $this->db->get(); // It will return query..
                                          return $query->result();  //  It will return result..
                            } else if ($Searching_Form_Data['Searching_option'] === "Receipt_Number") {
                                          $this->db->select('' . DB_PREFIX . 'stu_mst.EnrollNo,' . DB_PREFIX . 'stu_mst.StudentName,' . DB_PREFIX . 'stu_mst.FatherName,' . DB_PREFIX . 'fee_trn.CourseCode,' . DB_PREFIX . 'stu_mst.Mobile1,' . DB_PREFIX . 'stu_mst.Add_User,' . DB_PREFIX . 'stu_mst.Mode_User');
                                          $this->db->from('' . DB_PREFIX . 'stu_mst');
                                          $this->db->join('' . DB_PREFIX . 'fee_trn', '' . DB_PREFIX . 'fee_trn.EnrollNo = ' . DB_PREFIX . 'stu_mst.EnrollNo', 'inner')->where(array('' . DB_PREFIX . 'fee_trn.ID' => $Searching_Form_Data['EnrollNo']));
                                          $query = $this->db->get(); // It will return query..
                                          return $query->result();  //  It will return result..
                            } else if ($Searching_Form_Data['Searching_option'] === "Between_Dates") {
                                          $dates = explode('-', $Searching_Form_Data['between_dates']);
                                          $d1 = date('Y-m-d', strtotime(trim($dates[0])));
                                          $d2 = date('Y-m-d', strtotime(trim($dates[1])));
                                          $query = $this->db->query("SELECT `" . DB_PREFIX . "scnb`.`EnrollNo`, `" . DB_PREFIX . "stu_mst`.`DOR`, `" . DB_PREFIX . "stu_mst`.`Stu_ID`, `" . DB_PREFIX . "stu_mst`.`StudentName`, `" . DB_PREFIX . "stu_mst`.`FatherName`, `" . DB_PREFIX . "scnb`.`CourseCode`, `" . DB_PREFIX . "stu_mst`.`Mobile1`, `" . DB_PREFIX . "scnb`.`Add_User`, `" . DB_PREFIX . "scnb`.`Mode_User`
            FROM (`" . DB_PREFIX . "stu_mst`) INNER JOIN `" . DB_PREFIX . "scnb` ON `" . DB_PREFIX . "scnb`.`EnrollNo` = `" . DB_PREFIX . "stu_mst`.`EnrollNo`
            WHERE `" . DB_PREFIX . "stu_mst`.`DOR`>= '{$d1}' AND `" . DB_PREFIX . "stu_mst`.`DOR`<= '{$d2}'");
                                          //   $query = $this->db->get(); // It will return query..
                                          return $query->result();  //  It will return result..
                            } else if ($Searching_Form_Data['Searching_option'] === "Advance_Search") {
                                          $qry = "";
                                          $Stu_Name = $Searching_Form_Data['Stu_Name'];
                                          $FatherName = $Searching_Form_Data['Father_Name'];
                                          $BatchCode = $Searching_Form_Data['Batch_Code'];
                                          $FacultyCode = $Searching_Form_Data['Faculty_Code'];
                                          $qry .= $Stu_Name != "" ? $qry != "" ? " and " . DB_PREFIX . "stu_mst.StudentName like '%$Stu_Name%'" : " " . DB_PREFIX . "stu_mst.StudentName like '%$Stu_Name%'" : "";
                                          $qry .= $FatherName != "" ? $qry != "" ? " and " . DB_PREFIX . "stu_mst.FatherName like '%$FatherName%'" : " " . DB_PREFIX . "stu_mst.FatherName like '%$FatherName%'" : "";
                                          $qry .= $BatchCode != "" ? $qry != "" ? " and " . DB_PREFIX . "scnb.BatchCode='$BatchCode'" : " " . DB_PREFIX . "scnb.BatchCode='$BatchCode'" : "";
                                          $qry .= $FacultyCode != "" ? $qry != "" ? " and " . DB_PREFIX . "scnb.FacultyCode='$FacultyCode'" : " " . DB_PREFIX . "scnb.FacultyCode='$FacultyCode'" : "";
                                          $query = $this->db->query("SELECT `" . DB_PREFIX . "scnb`.`EnrollNo`, `" . DB_PREFIX . "stu_mst`.`DOR`, `" . DB_PREFIX . "stu_mst`.`Stu_ID`, `" . DB_PREFIX . "stu_mst`.`StudentName`, `" . DB_PREFIX . "stu_mst`.`FatherName`, `" . DB_PREFIX . "scnb`.`CourseCode`, `" . DB_PREFIX . "stu_mst`.`Mobile1`, `" . DB_PREFIX . "scnb`.`Add_User`, `" . DB_PREFIX . "scnb`.`Mode_User`
            FROM (`" . DB_PREFIX . "stu_mst`) INNER JOIN `" . DB_PREFIX . "scnb` ON `" . DB_PREFIX . "scnb`.`EnrollNo` = `" . DB_PREFIX . "stu_mst`.`EnrollNo`
            WHERE $qry");
                                          //   $query = $this->db->get(); // It will return query..
                                          return $query->result();  //  It will return result..
                            }
                            $query = $this->db->select('EnrollNo')->from(DB_PREFIX . "stu_mst")->order_by('Stu_ID', 'DESC')->limit(1);
                            $result = $query->get()->result();
                            if (!empty($result))
                                          return substr($result[0]->EnrollNo, 5) + 1;
                            else
                                          return 1;
              }

              function late_payment($EnrollNo, $ReceiptDay, $FeeType_Code = 'Monthly') {
                            $HeadBranch = 'IBMS';
                            $Branch = 'IBMS';
                            $result = $this->db->get_where('' . DB_PREFIX . 'scnb', array('EnrollNo' => $EnrollNo))->result();
                            $result1 = $this->db->get_where('' . DB_PREFIX . 'late_fine', array('HeadBranch' => $HeadBranch, 'Branch' => $Branch))->result();
//        $result2 = $this->db->get_where(''.DB_PREFIX.'stu_mst', array('EnrollNo'=>$EnrollNo));
//       echo $DOR = $result2[0]->DOR;
//        $today = date('Y-m-d',time());
//        if($today==$DOR)
//            return 0;
                            // print_r($result1);
                            $this->load->model('fee/fee_collect_model');
                            $last_fee_record = $this->fee_collect_model->last_fee_record($result[0]->EnrollNo, $result[0]->CourseCode, $FeeType_Code);
                            if (!isset($last_fee_record[0]))
                                          return 0;
                            $stu_month_day = $result[0]->Due_Date;
                            $next_due_date_was = $last_fee_record[0]->NextDueDate;
                            $next_due_date_was = strtotime($current_due_date = date('Y', strtotime($next_due_date_was)) . "-" . date('m', strtotime($next_due_date_was)) . "-" . $stu_month_day);
                            $current_due_date = strtotime(date('Y', time()) . "-" . date('m', time()) . "-" . $ReceiptDay);
                            //  $current_due_date = time();
                            $datediff = $current_due_date - $next_due_date_was;
                            $days = floor($datediff / (60 * 60 * 24));
                            if ($days > 0)
                                          return abs($days * $result1[0]->Late_Payment_Fee);
                            else
                                          return 0;
                            //  $month_day = $ReceiptDay;
                            // max_day_limit here for .. if due date is 5 then fine will start after 5 or how many days after.
                            // $stu_due_day = ($stu_month_day + ($result1[0]->Max_Day_Limit_After_Due_Date));
//        if ($stu_due_day < $month_day) {
//            return($result1[0]->Late_Payment_Fee * ($month_day - $stu_due_day));
//        } else {
//            return 0;
//        }
              }

              function delete($data_to_delete) {
                            global $data;
                            if (empty($data_to_delete))
                                          return array(FALSE, "Sorry Unable to fetch data !!");
                            $_key = isset($data_to_delete['_key']) ? $data_to_delete['_key'] : '';
                            if ($_key == "")
                                          return array(FALSE, "Key is not defined !!");
                            else {
                                          if ($_key == "add_del_update_batch") {
                                                        $action = isset($data_to_delete['_action']) ? $data_to_delete['_action'] : '';
                                                        if ($action == "Update") {
                                                                      //  $this->util_model->printr($data_to_delete);

                                                                      if (empty($data_to_delete['has_to_update']))
                                                                                    return array(FALSE, "Please select at Least One students");
                                                                      else {

                                                                                    $BatchID = $data_to_delete['BatchID'];
                                                                                    $FacultyID = $data_to_delete['FacultyID'];
                                                                                    $scnb_statusID = $data_to_delete['scnb_statusID'];
                                                                                    $Remarks = $data_to_delete['Remarks'];
                                                                                    if ($BatchID == "") {
                                                                                                  return array(FALSE, $this->util_model->get_err_msg("BatchCodeBlank"));
                                                                                    }
                                                                                    if ($FacultyID == "") {
                                                                                                  return array(FALSE, $this->util_model->get_err_msg("FacultyCodeBlank"));
                                                                                    }
                                                                                    if ($scnb_statusID == "") {
                                                                                                  return array(FALSE, $this->util_model->get_err_msg("Bat_StaBlank"));
                                                                                    }
                                                                                    $Mode_UserID = $data['Session_Data']['IBMS_USER_ID'];


                                                                                    $set = " BatchID='$BatchID',FacultyID='$FacultyID',BatchStatusID='$scnb_statusID',Mode_User='$Mode_UserID',Remarks='$Remarks'  ";
                                                                                    $where = "";
                                                                                    $Student_to_allocate = 0;
                                                                                    foreach ($data_to_delete['has_to_update'] as $EnrollNo_____CourseCode) {
                                                                                                  
                                                                                                  $Stu_details = explode("_____", $EnrollNo_____CourseCode); // joined using 5 underscore     
                                                                                                  if ($Stu_details[2] != $FacultyID || $Stu_details[3] != $BatchID) {
                                                                                                                $Student_to_allocate++;
                                                                                                  }
                                                                                                  $where.="  (Stu_ID='{$Stu_details[0]}' and CourseID='{$Stu_details[1]}' and BatchID='{$Stu_details[3]}' and FacultyID='{$Stu_details[2]}') or";
                                                                                    }



                                                                                    // $Student_to_allocate = count($data_to_delete['has_to_update']);
                                                                                    if($Student_to_allocate){
                                                                                    if ($FacultyID != "") {
                                                                                                  $this->load->model('batch/batch_model');
                                                                                                  $space_in_a_batch = $this->batch_model->space_in_batch($Student_to_allocate, $FacultyID, $BatchID);
                                                                                                  if (!$space_in_a_batch[0]) {
                                                                                                                return array(FALSE, $space_in_a_batch[1]);
                                                                                                  }
                                                                                    }}


                                                                                    $where = substr($where, 0, -3);
                                                                                    $query = "Update " . DB_PREFIX . "stu_batches set " . $set . " where " . $where;
                                                                                    if ($this->db->query($query)) {
                                                                                                  $batch_status_updated = TRUE; //$this->db->query("update " . DB_PREFIX . "batch_master set `AllotedStd` = `AllotedStd`+$Student_to_allocate where BatchID='{$BatchID}' and FacultyID='{$FacultyID}'");
                                                                                                  if ($batch_status_updated)
                                                                                                                return array(TRUE, "Batch Updated Successfully !!");
                                                                                                  else
                                                                                                                return array(FALSE, "Error while Updating Batch Status !!");
                                                                                    } else {
                                                                                                  return array(FALSE, "Error while running update_sring");
                                                                                    }
                                                                      }
                                                        } else if ($action == "Add") {
                                                                      // add batch
                                                                      // $this->util_model->printr($data_to_delete);
                                                                      $BatchID = $data_to_delete['BatchID'];
                                                                      $FacultyID = $data_to_delete['FacultyID'];
                                                                      $scnb_statusID = $data_to_delete['scnb_statusID'];
                                                                      $Remarks = $data_to_delete['Remarks'];
                                                                      if ($BatchID == "") {
                                                                                    return array(FALSE, $this->util_model->get_err_msg("BatchCodeBlank"));
                                                                      }
                                                                      if ($FacultyID == "") {
                                                                                    return array(FALSE, $this->util_model->get_err_msg("FacultyCodeBlank"));
                                                                      }
                                                                      if ($scnb_statusID == "") {
                                                                                    return array(FALSE, $this->util_model->get_err_msg("Bat_StaBlank"));
                                                                      }
                                                                      $Student_to_allocate = count($data_to_delete['has_to_update']);
                                                                      if ($FacultyID != "") {
                                                                                    $this->load->model('batch/batch_model');
                                                                                    $space_in_a_batch = $this->batch_model->space_in_batch($Student_to_allocate, $FacultyID, $BatchID);
                                                                                    if (!$space_in_a_batch[0]) {
                                                                                                  return array(FALSE, $space_in_a_batch[1]);
                                                                                    }
                                                                      }
                                                                      $data_to_insert = array();
                                                                      foreach ($data_to_delete['has_to_update'] as $EnrollNo_____CourseCode) {
                                                                                    $Stu_details = explode("_____", $EnrollNo_____CourseCode); // joined using 5 underscore     

                                                                                    if ($this->util_model->check_aready_exits(DB_PREFIX . "stu_batches", array("FacultyID" => $FacultyID, "BatchID" => $BatchID, "BatchStatusID" => $scnb_statusID)))
                                                                                                  continue;

                                                                                    $row = array();
                                                                                    $row = array(
                                                                                        "Stu_ID" => $Stu_details[0],
                                                                                        "CourseID" => $Stu_details[1],
                                                                                        "FacultyID" => $FacultyID,
                                                                                        "BatchStatusID" => $scnb_statusID,
                                                                                        "BatchID" => $BatchID,
                                                                                        "Remarks" => $Remarks
                                                                                    );

                                                                                    $row = $this->util_model->add_common_fields($row);
                                                                                    $row = $this->util_model->add_mode_user($row);
                                                                                    $data_to_insert[] = $row;
                                                                      }
                                                                      if (!empty($data_to_insert)) {
                                                                                    if ($this->db->insert_batch(DB_PREFIX . "stu_batches", $data_to_insert))
                                                                                                  return array(TRUE, "Batch Added Successfully !!");
                                                                                    else
                                                                                                  return array(FALSE, "Error while Inserting batch");
                                                                      }else {
                                                                                    return array(FALSE, "Student/s Already exits in that batch !!");
                                                                      }
                                                        }
                                          } elseif ($_key == "del_course") {
                                                        $CourseID = $this->util_model->url_decode($data_to_delete['ID']);
                                                        $this->db->select('*')->from('' . DB_PREFIX . 'stu_courses')->where(array("CourseID" => $CourseID));
                                                        $course_taken_by_students = $this->db->count_all_results();
                                                        if (!$course_taken_by_students) {
                                                                      if ($this->db->delete('' . DB_PREFIX . 'course_mst', array('CourseID' => $CourseID))) {
                                                                                    return array(1, "");
                                                                      } else {
                                                                                    return array(0, "Error While Deleting Course !!");
                                                                      }
                                                        } else {
                                                                      return array(False, "Course has been allocated to $course_taken_by_students students, Can't be deleted !!");
                                                        }
                                          } elseif ($_key == "del_Student") {
                                                        $EnrollNo = trim($data_to_delete['EnrollNo']);
                                                        $CourseCode = $this->util_model->url_decode($data_to_delete['CourseCode']); // not being used right now                 
                                                        $this->load->model('adm/admission_model');
                                                        return array($this->admission_model->Del_Admission_Course($EnrollNo), '');
                                          } elseif ($_key == "del_batch") {
                                                        $BatchCode = $data_to_delete['BatchCode1'];
                                                        $this->load->model('batch/batch_model');
                                                        $total_allocated_student_in_this_batch = $this->batch_model->no_of_student_in_a_batch($BatchCode, 2);
                                                        if ($total_allocated_student_in_this_batch > 1) {
                                                                      return array(0, $total_allocated_student_in_this_batch . " Students are allocated in this, cant be delete !!");
                                                        } else {
                                                                      return array($this->batch_model->Del_Batch($BatchCode));
                                                        }
                                          } else if ($_key == "del_Fee_plan") {
                                                        $Fee_Plan_ID = $data_to_delete['Fee_Plan_ID'];
                                                        $this->load->model('fee/fee_collect_model');
                                                        $succ = $this->fee_collect_model->Del_Fee_plan($Fee_Plan_ID);
                                                        if (!$succ) {
                                                                      $q = $this->db->get_where(DB_PREFIX . "fee_trn", array("Individual_fee_plan_id" => $Fee_Plan_ID));
                                                                      $result = $q->result();
                                                                      $Receipt_no_taken = "";
                                                                      foreach ($result as $Fee_Plan_Row) {
                                                                                    $Receipt_no_taken .=$Fee_Plan_Row->ID . " ,";
                                                                      }
                                                                      $Receipt_no_taken = substr($Receipt_no_taken, 0, -1);
                                                                      return array($succ, $succ ? "" : "Sorry fees has been taken from this Plan, Receipt no $Receipt_no_taken is/are taken from this fee plan !!");
                                                        } else {
                                                                      return array(TRUE, "");
                                                        }
                                          } else if ($_key == "del_Fee_receipt") {
                                                        $receipt_no = $data_to_delete['receipt_no'];
                                                        $EnrollNo = $data_to_delete['EnrollNo'];
                                                        $CourseCode = $data_to_delete['CourseCode'];
                                                        $this->load->model('fee/fee_collect_model');
                                                        $fee_details = $this->fee_collect_model->all_fee_records_from_receipt_number($receipt_no);

                                                        $fee_plan_ID_to_update = $fee_details[0]->Individual_fee_plan_id;
                                                        if ($this->db->delete(DB_PREFIX . "fee_trn", array("ID" => $fee_details[0]->ID))) {
                                                                      if ($fee_details[0]->FeeType_Code != "Bal") {
                                                                                    if ($this->db->query("UPDATE  `" . DB_PREFIX . "individual_fee_plan` SET  `Total_paid` =  `Total_paid` -1 WHERE ID =$fee_plan_ID_to_update")) {
                                                                                                  
                                                                                    } else {
                                                                                                  return array(FALSE, "Sorry, Unable to Update Last Balance, and Delete Fee Record !!");
                                                                                    }
                                                                      }
                                                                      $last_fee_recored = $this->fee_collect_model->last_fee_record($EnrollNo, $CourseCode);
                                                                      if (!empty($last_fee_recored)) {
                                                                                    $data_to_update = array(
                                                                                        "OtherAmt" => $last_fee_recored[0]->OtherAmt - $fee_details[0]->BalanceAmt,
                                                                                        "TotalAmt" => $last_fee_recored[0]->TotalAmt - $fee_details[0]->BalanceAmt,
                                                                                        "BalanceAmt" => $last_fee_recored[0]->BalanceAmt - $fee_details[0]->BalanceAmt,
                                                                                        "NetPayableAmt" => $last_fee_recored[0]->NetPayableAmt - $fee_details[0]->NetPayableAmt
                                                                                    );
                                                                                    if ($this->db->update('' . DB_PREFIX . 'fee_trn', $data_to_update, array("ID" => $last_fee_recored[0]->ID))) {
                                                                                                  return array(TRUE, "");
                                                                                    } else {
                                                                                                  $data_to_update = array(
                                                                                                      "OtherAmt" => $last_fee_recored[0]->OtherAmt + $fee_details[0]->BalanceAmt,
                                                                                                      "TotalAmt" => $last_fee_recored[0]->TotalAmt + $fee_details[0]->BalanceAmt,
                                                                                                      "BalanceAmt" => $last_fee_recored[0]->BalanceAmt + $fee_details[0]->BalanceAmt,
                                                                                                      "NetPayableAmt" => $last_fee_recored[0]->NetPayableAmt + $fee_details[0]->NetPayableAmt
                                                                                                  );
                                                                                                  $this->db->update(DB_PREFIX . "fee_trn", $data_to_update, array("ID" => $last_fee_recored[0]->ID));
                                                                                                  return array(FALSE, "Sorry, Unable to Delete Fee Recored !!");
                                                                                    }
                                                                      }
                                                                      return array(TRUE, "Updated Successfully");
                                                        } else {
                                                                      return array(FALSE, "Sorry, Unable to Update in Fee Plan, and Delete Fee Record !!");
                                                        }
                                          } else if ($_key == "del_designation") {
                                                        $Designation_Code = $data_to_delete['Designation_Code'];
                                                        $this->db->select('*')->from('' . DB_PREFIX . 'employee')->where(array("Designation" => $Designation_Code));
                                                        $Designation_taken_by_Emp = $this->db->count_all_results();
                                                        if (!$Designation_taken_by_Emp) {
                                                                      if ($this->db->delete('' . DB_PREFIX . 'designation', array('Code' => $Designation_Code))) {
                                                                                    return array(1, "");
                                                                      } else {
                                                                                    return array(0, "Error While Deleting Designation !!");
                                                                      }
                                                        } else {
                                                                      return array(False, "Designation has been allocated to $Designation_taken_by_Emp Employees, Can't be deleted !!");
                                                        }
                                          } else if ($_key == "del_FeeType_Code") {
                                                        $del_FeeType_Code = $data_to_delete['FeeType_Code'];
                                                        $this->db->select('*')->from('' . DB_PREFIX . 'fee_trn')->where(array("FeeType_Code" => $del_FeeType_Code));
                                                        $Fee_taken_by_FeeType_Code = $this->db->count_all_results();
                                                        if (!$Fee_taken_by_FeeType_Code) {
                                                                      if ($this->db->delete('' . DB_PREFIX . 'fee_type_mst', array('FeeType_Code' => $del_FeeType_Code))) {
                                                                                    return array(1, "");
                                                                      } else {
                                                                                    return array(0, "Error While Deleting FeeType Code !!");
                                                                      }
                                                        } else {
                                                                      return array(False, "Fees has been taken from $Fee_taken_by_FeeType_Code Fee type, Can't be deleted !!");
                                                        }
                                          } else if ($_key == "del_qualification") {
                                                        $quali_code = $data_to_delete['Qualification_Code'];
                                                        $this->db->select('*')->from('' . DB_PREFIX . 'stu_mst')->where(array("Quali" => $quali_code));
                                                        $Quali_taken_by_Quali_Code = $this->db->count_all_results();
                                                        if (!$Quali_taken_by_Quali_Code) {
                                                                      if ($this->db->delete('' . DB_PREFIX . 'qualification', array('Code' => $quali_code))) {
                                                                                    return array(1, "");
                                                                      } else {
                                                                                    return array(0, "Error While Deleting FeeType Code !!");
                                                                      }
                                                        } else {
                                                                      return array(False, "$quali_code Qualification has been taken by $Quali_taken_by_Quali_Code, Can't be deleted !!");
                                                        }
                                          } else if ($_key == "del_Emp_Code") {
                                                        $emp_code = $data_to_delete['Emp_Code'];
                                                        if ($this->db->delete('' . DB_PREFIX . 'employee', array('Emp_Code' => $emp_code))) {
                                                                      return array(1, "");
                                                        } else {
                                                                      return array(0, "Error While Deleting Employee Code !!");
                                                        }
                                          } else if ($_key == "Due_Date_update") {
                                                        $due_date = $data_to_delete['due_date_updated'];
                                                        $EnrollNo = $data_to_delete['EnrollNo'];
                                                        $CourseCode = $data_to_delete['CourseCode'];
                                                        if ($this->db->update(DB_PREFIX . "scnb", array("Due_Date" => $due_date), array("EnrollNo" => $EnrollNo, "CourseCode" => $CourseCode))) {
                                                                      return array(TRUE, "Due Date Updated SuccessFully");
                                                        } else {
                                                                      return array(FALSE, "Error while Updating !!");
                                                        }
                                          } else if ($_key == "del_UID") {
                                                        $del_UID = $data_to_delete['UTID'];
                                                        $result = $this->db->get_where(DB_PREFIX . "employee", array("UserTypeID" => $del_UID));
                                                        if ($result->num_rows == 0) {
                                                                      if ($this->db->delete(DB_PREFIX . "usertypes", array("UTID" => $del_UID))) {
                                                                                    return array(TRUE, "Deleted Successfully !!");
                                                                      } else {
                                                                                    return array(FALSE, "Error while Deleting User Type !!");
                                                                      }
                                                        } else {
                                                                      return array(FALSE, "This User type is already allocated to your $result->num_rows employees, Error while Deleting !!");
                                                        }
                                          } else if ($_key == "del_menu") {
                                                        $MID = $data_to_delete['MID'];
                                                        if (!$this->db->delete(DB_PREFIX . 'menus', array("MID" => $MID))) {
                                                                      return array(FALSE, "Error while Deleting Menu From Menu Master !!");
                                                        } else {
                                                                      if (!$this->db->delete(DB_PREFIX . 'menu_access', array("MID" => $MID))) {
                                                                                    return array(FALSE, "Error while Deleting Menu From Menu Access !!");
                                                                      } else {
                                                                                    return array(TRUE, "Deleted Successfully !!");
                                                                      }
                                                        }
                                          } else if ($_key == "del_course_cat") {
                                                        if (!isset($data_to_delete['course'])) {
                                                                      return array(TRUE, "Unable to get data to delete !!");
                                                        }
                                                        $this->load->model('courses/course');
                                                        return $this->course->delete_course_cat($data_to_delete['C_CID']);
                                          } else if ($_key == "del_Enq") {
                                                        if (!isset($data_to_delete['E_Code'])) {
                                                                      return array(TRUE, "Unable to get data to delete !!");
                                                        }
                                                        $E_Code = $data_to_delete['E_Code'];
                                                        $this->load->model('enquiry/m_enquiry');
                                                        return $this->m_enquiry->del_enq($E_Code);
                                          } else if ($_key == "del_source") {
                                                        if (!isset($data_to_delete['src_id'])) {
                                                                      return array(FALSE, "Unable to get data to delete !!");
                                                        }
                                                        $src_id = $data_to_delete['src_id'];
                                                        $this->load->model('enquiry/m_source');
                                                        return $this->m_source->deleteSource($src_id);
                                          } else if ($_key == "del_response") {
                                                        if (!isset($data_to_delete['UniqueKey'])) {
                                                                      return array(FALSE, "Unable to get data to delete !!");
                                                        }
                                                        $rid = $data_to_delete['UniqueKey'];
                                                        $this->load->model('enquiry/m_response');
                                                        return $this->m_response->deleteResponse($rid);
                                          } else if ($_key == "del_country") {
                                                        if (!isset($data_to_delete['ID'])) {
                                                                      return array(FALSE, "Unable to get data to delete !!");
                                                        }
                                                        $id = $data_to_delete['ID'];
                                                        $this->load->model('enquiry/m_country');
                                                        return $this->m_country->deletecountry($id);
                                          } else if ($_key == "del_followup_record") {
                                                        if (!isset($data_to_delete['ID'])) {
                                                                      return array(FALSE, "Unable to get data to delete !!");
                                                        }
                                                        // print_r($data_to_delete);
                                                        $this->load->model('enquiry/m_enquiry');
                                                        $id = $data_to_delete['ID'];
                                                        return $this->m_enquiry->delete_follow_up($id);
                                          } else if ($_key == "del_state") {
                                                        if (!isset($data_to_delete['ID'])) {
                                                                      return array(FALSE, "Unable to get data to delete !!");
                                                        }
                                                        // print_r($data_to_delete);
                                                        $this->load->model('enquiry/m_state');
                                                        $id = $data_to_delete['ID'];
                                                        return $this->m_state->deletestate($id);
                                          } else if ($_key == "del_city") {
                                                        if (!isset($data_to_delete['ID'])) {
                                                                      return array(FALSE, "Unable to get data to delete !!");
                                                        }
                                                        // print_r($data_to_delete);
                                                        $this->load->model('enquiry/m_city');
                                                        $id = $data_to_delete['ID'];
                                                        return $this->m_city->deletecity($id);
                                          } elseif ($_key == "del_locality") {
                                                        if (!isset($data_to_delete['ID'])) {
                                                                      return array(FALSE, "Unable to get data to delete !!");
                                                        }
                                                        // print_r($data_to_delete);
                                                        $this->load->model('enquiry/locality');
                                                        $id = $data_to_delete['ID'];
                                                        return $this->locality->deletelocality($id);
                                          } elseif ($_key == "del_cdoing") {
                                                        if (!isset($data_to_delete['ID'])) {
                                                                      return array(FALSE, "Unable to get data to delete !!");
                                                        }
                                                        // print_r($data_to_delete);
                                                        $this->load->model('enquiry/m_cdoing');
                                                        $id = $data_to_delete['ID'];
                                                        return $this->m_cdoing->deletecdoing($id);
                                          } elseif ($_key == "del_batch_status") {
                                                        if (!isset($data_to_delete['ID'])) {
                                                                      return array(FALSE, "Unable to get data to delete !!");
                                                        }
                                                        // print_r($data_to_delete);
                                                        $this->load->model("batch/m_bstatus");
                                                        $id = $data_to_delete['ID'];
                                                        return $this->m_bstatus->deletebatchstatus($id);
                                          }
                            }
              }

              /*
                this used to check already exits value in row .. in this you have to pass table, col_name then value in
               * indexive array
               *      */

              public function check_aready_exits($data_to_check) {
                            /*
                             * i m passing the value and id
                             * id i will insert $table_Array  and i would get table_name and column name
                             * using this method i will hide my table and column name */
                            $check_branch = TRUE;
                            $dont_check_branch = FALSE;
                            $table_array = array("1" => array(DB_PREFIX . "employee", "Emp_Code", $check_branch),
                                "2" => array(DB_PREFIX . "employee", "UserName", $check_branch),
                                "3" => array(DB_PREFIX . "course_mst", "CourseCode", $check_branch),
                                "4" => array(DB_PREFIX . "course_mst", "Course_Name", $check_branch),
                                "5" => array(DB_PREFIX . "course_cat_mst", "C_CatCode", $check_branch),
                                "6" => array(DB_PREFIX . "course_cat_mst", "C_CatName", $check_branch),
                                "7" => array(DB_PREFIX . "e_source_mst", "Src_Code", $check_branch),
                                "8" => array(DB_PREFIX . "e_source_mst", "Src_Name", $check_branch),
                                "9" => array(DB_PREFIX . "current_doing", "Code", $check_branch),
                                "10" => array(DB_PREFIX . "current_doing", "Name", $check_branch),
                                "11" => array(DB_PREFIX . "countries", "name", $dont_check_branch)
                            );
                            $whr = array($table_array[$data_to_check[0]][1] => $data_to_check[1]);
                            // checking if branch check allowed then adding branch id from session
                            if ($table_array[$data_to_check[0]][2]) {
                                          global $data;
                                          $whr["BranchID"] = $data['Session_Data']['IBMS_BRANCHID'];
                            }
                            $result = $this->db->get_where($table_array[$data_to_check[0]][0], $whr);
                            return $result;
              }

}

?>