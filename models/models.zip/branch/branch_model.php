<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of course
 *
 * @author Mr. Anup
 */
class branch_model extends CI_Model {

    function __construct() {
        parent::__construct();
    }

    /*
     * branch_list_with_branch_Cat($head_branch)
     * used by menu/add_menu
     */
    public function branch_list_with_branch_Cat($head_branch=0) {
        if($head_branch){
            $this->db->where("HeadB",1);
        }
        $query = $this->db->select('*')->from("nexgen_branch_mst")->order_by('BranchCode,Bname');
        $result = $query->get()->result();
        $branch_list_with_branch_Cat =array();
        foreach ($result as $value) {
            $branch_list_with_branch_Cat[$value->BranchID] = $value->BranchCode;
        }
        return $branch_list_with_branch_Cat;
    }
//    public function accessed_branches($UTID,$BranchID){
//        $this->db->select("bm.BranchCode,bm.BranchID from ".DB_PREFIX."branch_mst bm");
//        $this->db->join(DB_PREFIX."branch_access ba", "bm.BranchID=ba.BranchID","INNER");
//        $this->db->where(array("ba.BranchID" => $BranchID, "ba.UTID" => $UTID, "ba.Status" => 1, "bm.Status" => 1))->order_by('bm.BranchCode');
//        $result = $this->db->get()->result();
//        
//        
//    }
    
    /*get branch setting

     * @param : BranchID
     * @return : return the all branch setting     */
    function get_branch_setting($BranchID){
                  $query = $this->db->get_where(DB_PREFIX."branch_settings",array("BranchID"=>$BranchID));
                  $result = $query->result();
                  return $result[0];
    }
    /*get branch details
     * @function get_branch_details($Branch Id) 
     * @param : BranchID
     * @return : return the all branch details 
     * already defined in util_model, that's why commentted over here    */
//     function get_branch_details($BranchID){
//                  $query = $this->db->get_where(DB_PREFIX."branch_mst",array("BranchID"=>$BranchID));
//                  $result = $query->result();
//                  return $result[0];
//    }
    //Get branch data from database(By Prabhu)
    public function get_branch_data($id) {
        $query = $this->db->get_where(DB_PREFIX . "branch_mst", array("bsid" => $id));
        $result = $query->result();
        return $result[0];
    }
   function branch_update($FormData, $id) {
//                 echo $id;
//                die($this->util_model->printr($FormData));
        $this->db->where(array("BranchID" => $id));
        if ($this->db->update(DB_PREFIX ."branch_mst", $FormData)) {
            return array("succ" => TRUE);
        } else {
            return array("succ" => FALSE);
        }
   }
    //insert new branch details in database(By Prabhu)
    function insert_branch($FormData) {
        if ($this->db->insert(DB_PREFIX ."branch_mst", $FormData)) {
            return array("succ" => TRUE);
        } else {
            return array("succ" => FALSE);
        }
    }
}