<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of mtoken
 *
 * @author Sammy Guergachi <sguergachi at gmail.com>
 */
class mtoken extends CI_Model {

    public function __construct() {
        parent::__construct();
    }

    function insert_token($FormData) {
        if ($this->db->insert(DB_PREFIX . "tokening_sys", $FormData)) {
            return array("succ" => TRUE,"token_id"=>$this->db->insert_id());
        } else {
            return array("succ" => FALSE);
        }
    }
    function insert_notify_users($FormData){
               $insert_notify_users = array();
                            foreach ($FormData['nuserid'] as $nuserid) {
                                          $insert_notify_users[] = array(
                                              "token_id" => $FormData['token_id'],
                                              "nuserid" => $nuserid,
                                              "Add_User" => $FormData['Add_User'],
                                              "Add_DateTime" => $FormData['Add_DateTime']);
                            }
                            //   die($this->util_model->printr($insert_notify_users));
                            if ($this->db->insert_batch(DB_PREFIX . 'tokening_noti_users', $insert_notify_users)) {
                                          return array("succ" => TRUE);
                            } else {
                                          return array("succ" => FALSE);
                            }   
    }

}
