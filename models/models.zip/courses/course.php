<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of course
 *
 * @author Mr. Anup
 */
class course extends CI_Model {

    function __construct() {
        parent::__construct();
    }

    public function Course_list_with_Course_Cat() {
        $query = $this->db->select()->from("nexgen_course_mst")->order_by('Course_Name');
        $result = $query->get()->result();
        $Course_list_with_Course_Cat = array();
        foreach ($result as $value) {
            $Course_list_with_Course_Cat[$value->CourseCode] = $value->CourseCode;
        }
        return $Course_list_with_Course_Cat;
       
    }
    
    //new course list display 
     public function Course_list_with_child($BranchID,$parentID=0,$parentName='',$C_CID=0) {
        $clist=array();
        $query = $this->db->select()->from(DB_PREFIX."course_mst");
        if($C_CID)
          $this->db->where(array("C_CID"=>$C_CID)); 
        $this->db->where(array('parentID'=>$parentID,'Status'=>1,'BranchID'=>$BranchID));
        $result = $query->get();
        foreach ($result->result_array() as $row) {
            $clist[]=array('parent'=>$row['CourseID'],'name'=>$parentName."".($parentName =="" ? "":" -> ").$row['Course_Name'],'child'=>  $this->Course_list_with_child($BranchID,$row['CourseID'], $parentName."".($parentName =="" ? "":" -> ").$row['Course_Name'],$C_CID));
        }
        
        return $clist ;
       
    }
    public function listConvert($List)
    {
        $clist=array();
        
        if($List!=null)
        {
        foreach ($List as $course) {
            
           $clist[$course['parent']]=$course['name'];
           $clist = $this->joinTwoarray($clist, $course['child']);

        }
      
        }
        
        return $clist;
                
    }
public function joinTwoarray($array1,$array2)
    {
        if($array2!=NULL)
        {
            foreach ($array2 as $value ){
        
             $array1[$value['parent']]=$value['name'];
             $array1=$this->joinTwoarray($array1, $value['child']);
            }
        }
       
        return $array1;
    }






//end of code course list displau
    public function all_Course_list($orderby = 'cm.Add_DateTime', $BranchIDs = '') {
        if ($BranchIDs != '') {
            $orderby = " cm.BranchID, " . $orderby;
            $this->db->where_in('cm.BranchID',$BranchIDs);
        }
        $query = $this->db->select("`cm`.`CourseID`,cm.Remarks, `cm`.`CourseCode`, `cm`.`Course_Name`, `t2`.`C_CatName`, `t2`.`C_CatCode`,cm.Duration,cm.MonthDay, `cm`.`Status`, `t3`.`Emp_Code` as Add_User, `t4`.`Emp_Code` as Mode_User,cm.Add_DateTime,cm.Mode_DateTime")->from("nexgen_course_mst cm");
        $this->db->join(DB_PREFIX . "course_cat_mst t2", "cm.C_CID=t2.C_CID", 'LEFT');
        $this->db->join(DB_PREFIX . "employee t3", "cm.Add_User=t3.Emp_ID", 'LEFT');
        $this->db->join(DB_PREFIX . "employee t4", "cm.Mode_User=t4.Emp_ID", 'LEFT');
        $this->db->where(array("cm.Status" => 1));
        $this->db->order_by($orderby, "DESC");
        $result = $query->get()->result();
        return $result;
    }

    public function all_CourseCat_list($BranchID = 0, $orderby = 'ccm.Add_DateTime', $order = "DESC") {
        global $data;
        if ($BranchID != 0) {
            $orderby = " ccm.BranchID, " . $orderby;
            $this->db->where(array("ccm.BranchID " => $BranchID));
        } else {
            $this->db->where(array("ccm.BranchID " => $data['Session_Data']['IBMS_BRANCHID']));
        }
        $query = $this->db->select("`ccm`.`C_CID`,`ccm`.`Sort`, `ccm`.`C_CatCode`, `ccm`.`C_CatName`,`ccm`.`Status`,`t3`.`Emp_Code` as Add_User, `t4`.`Emp_Code` as Mode_User,ccm.Add_DateTime,ccm.Mode_DateTime")->from(DB_PREFIX . "course_cat_mst ccm");
        $this->db->join(DB_PREFIX . "employee t3", "ccm.Add_User=t3.Emp_ID", 'LEFT');
        $this->db->join(DB_PREFIX . "employee t4", "ccm.Mode_User=t4.Emp_ID", 'LEFT');
        $this->db->order_by($orderby, $order);
        $result = $query->get()->result();
        return $result;
    }

//    public function all_distinct_CourseCatagory_list() {
//        $query = $this->db->select('Category'); //->from("nexgen_course_mst");
//        $this->db->distinct();
//        $query = $this->db->get('nexgen_course_mst');
//        $result = $query->result();
//        $all_Course_Category_List = array();
//        // print_r($result);
//        foreach ($result as $value) {
//            $all_Course_Category_List["{$value->Category}"] = $value->Category;
//        }
//        return $all_Course_Category_List;
//    }
//    public function all_distinct_CourseCatagoryCode_list() {
//        $query = $this->db->select('CategoryCode'); //->from("nexgen_course_mst");
//        $this->db->distinct();
//        $query = $this->db->get('nexgen_course_mst');
//        $result = $query->result();
//        //print_r($result);
//        $all_Course_CategoryCode_List = array();
//        foreach ($result as $value) {
//            $all_Course_CategoryCode_List["{$value->CategoryCode}"] = $value->CategoryCode;
//        }
//        return $all_Course_CategoryCode_List;
//    }
    function form_validation($POST) {
        $err_codes = '';
        if (isset($POST['CourseCode']) && $POST['CourseCode'] == "") {
            $err_codes.='C_CodeBlank' . ERR_DELIMETER;
        }
        if (isset($POST['Course_Name']) && $POST['Course_Name'] == "") {
            $err_codes.='C_NameBlank' . ERR_DELIMETER;
        }
        if (isset($POST['Duration']) && $POST['Duration'] == "") {
            $err_codes.='C_DurationBlank' . ERR_DELIMETER;
        }
        $valid = $err_codes == '' ? TRUE : FALSE;
        return array("_err" => $valid, "_err_codes" => $err_codes);
    }

    function Course_save_update() {
        $FormData = $this->input->post(); // getting all form data
        $validates = $this->form_validation($FormData); // validating the form
       // die($this->util_model->printr($validates));
        if (!$validates['_err']) {
            return array("succ" => false, "_err_codes" => $validates['_err_codes']);
        }
        if ($FormData["Add_Course"] === "Save") {
            /* if clicked on new category */
            if ($FormData['New_Category'] != "") {
                $data_to_insert = array("BranchID" => $FormData['BranchID'],
                    "C_CatCode" => $FormData['New_Category'],
                    "C_CatName" => $FormData['New_Category'],
                    "Status"=>TRUE);
                $data_to_insert = $this->util_model->add_common_fields($data_to_insert);
                if(!$this->db->insert(DB_PREFIX."course_cat_mst",$data_to_insert))
                    return array("succ" => FALSE, "_err_codes" => "C_CatAddErr");
                else{
                    $FormData['C_CID'] = $this->db->insert_id(); 
                }
            }

            $FormData = $this->util_model->add_common_fields($FormData);
            $FormData = $this->util_model->unset_array($FormData,array('Add_Course','New_Category'));
           // DIE($this->util_model->printr($FormData));
            if ($this->db->insert("nexgen_course_mst", $FormData)) {
                return array("succ" => TRUE, "_err_codes" => "C_AddSucc");
            } else {
                return array("succ" => FALSE, "_err_codes" => "C_AddErr");
            }
        } else if ($FormData["Add_Course"] === "Update") {
            $FormData = $this->util_model->add_mode_user($FormData);
            $CourseID = $FormData['courseid'];
            $this->db->where('CourseID', $FormData['courseid']);
            $FormData = $this->util_model->unset_array($FormData, array('New_Category', 'courseid', 'Add_Course'));
            if ($this->db->update(DB_PREFIX . "course_mst", $FormData)) {
                return array("succ" => TRUE, "_err_codes" => "C_UpSucc", "CourseID" => $CourseID);
            } else {
                return array("succ" => TRUE, "_err_codes" => "C_ErrUpSucc", "CourseID" => $CourseID);
            }
        }
    }

    function cat_form_validation($POST) {
        $err_codes = '';
        if (isset($POST['C_CatCode']) && $POST['C_CatCode'] == "") {
            $err_codes.='C_CatCodeBlank' . ERR_DELIMETER;
        }
        if (isset($POST['C_CatName']) && $POST['C_CatName'] == "") {
            $err_codes.='C_CatNameBlank' . ERR_DELIMETER;
        }
        $valid = $err_codes == '' ? TRUE : FALSE;
        return array("_err" => $valid, "_err_codes" => $err_codes);
    }

    public function save_course_cat($FormData) {
        $validates = $this->cat_form_validation($FormData); // validating the form
        if (!$validates['_err']) {
            return array("succ" => false, "_err_codes" => $validates['_err_codes']);
        }
        if ($FormData["Add_CourseCat"] === "Save") {
            $FormData = $this->util_model->add_common_fields($FormData);
            unset($FormData['Add_CourseCat']);
            if ($this->db->insert(DB_PREFIX . "course_cat_mst", $FormData)) {
                return array("succ" => TRUE, "_err_codes" => "C_CatAddSucc");
            } else {
                return array("succ" => FALSE, "_err_codes" => "C_CatAddErr");
            }
        }
    }

    public function delete_course_cat($C_CID) {
        $result = $this->db->get_where(DB_PREFIX . "course_mst", array("C_CID" => $C_CID));
        if ($result->num_rows == 0) {
            if ($this->db->delete(DB_PREFIX . "course_cat_mst", array("C_CID" => $C_CID))) {
                return array(TRUE, "Deleted Successfully !!");
            } else {
                return array(FALSE, "Error while Deleting Course Category  !!");
            }
        } else {
            return array(FALSE, "This Course Category is already allocated to your $result->num_rows Courses, First Delete Them !!");
        }
    }
    public function get_course_details($CourseID) {
        $query = $this->db->get_where(DB_PREFIX . 'course_mst', array("CourseID" => $CourseID));
        if ($this->db->count_all_results() > 0) {
            $course_details = $query->first_row();
            return $course_details;
        } else {
            return FALSE;
        }
    }
    
    public function get_details_from_database($CourseCode = '', $only_duration = 0) {
        $query = $this->db->get_where(DB_PREFIX.'course_mst', array("CourseCode" => $CourseCode));
        if ($this->db->count_all_results() > 0) {
            $course_details = $query->first_row();
            if ($only_duration)
                return $course_details->Duration . " " . $course_details->MonthDay;
            return $course_details; //sending first row
        }else {
            return FALSE;
        }
    }
    
    
}
