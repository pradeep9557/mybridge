<?php
/*

 * @model util_model
 * @auther : Anup kumar
 * @Created : 10 March 2015 */

class util_model extends CI_Model {

    function __construct() {
        parent::__construct();
    }

    public function all_month_list() {
        $c_month = date("F", time());
        $month_list = array();
        $month_list[$c_month] = $c_month;
        for ($i = 1; $i < 13; $i++) {
            $value = date("F", strtotime("+$i months"));
            $month_list[$value] = $value;
        }

        return array($month_list, $c_month);
    }

   

    public function yes_no() {
        return array(0 => 'No', 1 => 'Yes');
    }

    public function _set_encrypt_cookie($cookie_data) {
        $this->load->helper('cookie');
        $cookie = array();
        foreach ($cookie_data as $cookie_raw) {
            $cookie[] = array(
                'name' => $cookie_raw['cname'],
                'value' => $this->encrypt_string($cookie_raw['cvalue']),
                'expire' => time() + 86500,
                'path' => '/',
            );
        }
        $this->input->multi_set_cookie($cookie);
    }

    public function trimmer($POST) {
        $user_data = array();
        foreach ($POST as $key => $value) {
            $user_data["$key"] = trim($value);
        }
        return $user_data;
    }

    public function _get_decrypted_cookie($cname) {
        $this->load->helper('cookie');
        return $this->decrypt_string($this->input->cookie($cname));
    }

    public function encrypt_string($string) {
        $this->load->library('encrypt');
        return $this->encrypt->encode($string);
    }

    public function decrypt_string($string) {
        $this->load->library('encrypt');
        return $this->encrypt->decode($string);
    }

    public function printr($data) {
        echo "<pre>";
        print_r($data);
        echo "</pre>";
    }

    function url_encode($CourseCode) {
        $CourseCode = str_replace('+', "plus", $CourseCode);
        $CourseCode = str_replace('&', "and_opertor", $CourseCode);
        $CourseCode = str_replace('/', "slash_opertor", $CourseCode);
        $CourseCode = str_replace('(', "open_pren", $CourseCode);
        $CourseCode = str_replace(')', "close_pren", $CourseCode);
        return $CourseCode;
    }

    function url_decode($CourseCode) {
        $CourseCode = str_replace('plus', "+", $CourseCode);
        $CourseCode = str_replace('and_opertor', "&", $CourseCode);
        $CourseCode = str_replace('%20', " ", $CourseCode);
        $CourseCode = str_replace('slash_opertor', "/", $CourseCode);
        $CourseCode = str_replace('open_pren', "(", $CourseCode);
        $CourseCode = str_replace('close_pren', ")", $CourseCode);
        return $CourseCode;
    }

    function set_error($data, $error, $_err_codes) {
        if ($error != '') {
            $data['error'] = $error == 1 ? TRUE : FALSE;
            $data['err_codes'] = $_err_codes;
        }
        return $data;
    }

    function result_e_code($error, $true_msg = '', $_err_string) {
        if (isset($error)) {
            if (!$error) {  // if error is not occurred
                ?>
                <script>
                    swal({
                        title: "Nice Job !!",
                        type: "success",
                        text: "<?= $this->get_err_msg($_err_string) ?>",
                        timer: 2000});
                </script>
                <!--                    <h6 id="succ_msg">
                                        <button type="button" class="btn btn-success btn-md"><?= $true_msg ?>
                                            <span class="glyphicon glyphicon-remove"></span> 
                                        </button></h6>-->
                <?php
            } else {
                $err_array = explode("404IBMS", $_err_string);
                array_pop($err_array);
                //  $this->util_model->printr($err_array);
                echo "<h6 class='succ_msg'>";
                foreach ($err_array as $_err_code) {
                    ?>
                    <button type="button" class="btn btn-danger btn-md"><?= $this->get_err_msg($_err_code) ?>
                        <span class="glyphicon glyphicon-remove"></span> 
                    </button>
                    <?php
                }
                echo "</h6>";
            }
        }
        //print_r($pre_filled_data);
    }

    function get_err_msg($_err_code) {
        $result = $this->db->get_where("nexgen_global_error", array("ErrCode" => $_err_code));
        $result_data = $result->result();
        if (!empty($result_data))
            return $result_data[0]->ErrCodeDes;
    }

    function show_result_error($error, $true_msg = SUCCESS_MSG, $false_msg = ERROR_MSG) {
        if (isset($error)) {
            if (!$error) {  // if error is not occurred
                ?>
                <script>
                    swal({
                        title: "Nice Job !!",
                        type: "success",
                        text: "<?= $true_msg ?>",
                        timer: 2000});
                </script>
                <!--                    <h6 id="succ_msg">
                                        <button type="button" class="btn btn-success btn-md"><?= $true_msg ?>
                                            <span class="glyphicon glyphicon-remove"></span> 
                                        </button></h6>-->
            <?php } else {
                ?> 
                <script>
                    swal({
                        title: "Error Occured",
                        type: "error",
                        text: "<?= $false_msg ?>",
                        timer: 2000});
                </script>
                <!--                    <h6 id="succ_msg">
                                        <button type="button" class="btn btn-danger btn-md"><? // $false_msg ?>
                                            <span class="glyphicon glyphicon-remove"></span> 
                </button></h6>-->
                <?php
            }
        }
        //print_r($pre_filled_data);
    }

    function active_deactive() {
        return array("1" => "Active", "0" => "De-Active");
    }

    function check_if_exits_then_delete($file_path) {
        $base_url = base_url();
        if (file_exists($file_path) && ($file_path != $base_url . "img/default_pic_and_sign/default.png" || $file_path != $base_url . "img/default_pic_and_sign/signature_scan.gif")) {
            unlink($file_path);
        }
    }

    function get_branch_details($BranchID) {
        $result = $this->db->get_where(DB_PREFIX . 'branch_mst', array("BranchID" => $BranchID));
        $result_data = $result->result();
        if (!empty($result_data))
            return $result_data[0];
    }

    function days_list() {
        $timestamp = strtotime('next Sunday');
        $days = array();
        for ($i = 0; $i < 7; $i++) {
            $day = strftime('%A', $timestamp);
            $days[$day] = $day;
            $timestamp = strtotime('+1 day', $timestamp);
        }
        return $days;
    }

    /*
      used to show the all branch
     *  branch_list_with_branch_Cat
     *  @access public    
     * @param $UserType here for controlling the number of branch user can see 
     * like admin can see all branch in dropdown
     * PRO can see current branch under which it has been registered. etc or 
     * custome as per user_types tables will defined the access of user
     * @param	$head_branch  TRUE for head branches
     */

    public function branch_list_with_branch_Cat($Session_Data, $head_branch = 0) {
        $UserTypeID = $Session_Data['IBMS_USER_TYPE'];
        //echo $UserTypeID;
        $BranchID = $Session_Data['IBMS_BRANCHID'];
      //  print_r($Session_Data);
        if ($head_branch) {
            $this->db->where("HeadB", 1);
        }
        $this->db->select('t1.`AccessBranchID`,t2.BranchCode')->from(DB_PREFIX . 'branch_access  t1');
        $this->db->join(DB_PREFIX . "branch_mst t2", "t1.AccessBranchID=t2.BranchID");
        $this->db->where(array("t1.BranchID" => $BranchID, "UTID" => $UserTypeID, "t1.Status" => 1, "t2.Status" => 1))->order_by('BranchCode,Bname');
        $result = $this->db->get()->result();
        $return_list = array();
        foreach ($result as $value) {
            $return_list[$value->AccessBranchID] = $value->BranchCode;
        }
        
        //die(print_r($return_list));
        return $return_list;
        
    }
//    public function add_common_field($action,$FormData,$Session_Data){
//        if($action=="add"){
//        $FormData['Add_User']=  $Session_Data['IBMS_USER_ID'];
//        $FormData['Add_DateTime'] = date(DB_DTF, strtotime(TIMEZONE));
//        }else{
//         $FormData['Mode_User']=  $Session_Data['IBMS_USER_ID'];   
//        }
//        
//    }
//    public function data_filter($data) {
//        foreach ($data as $key => $value) {
//            $data[$key] = $this->db->escape_str($value);
//        }
//        return $data;
//    }

    public function get_list($vkey, $skey, $table, $branchid = 0, $sort_col = 'Sort', $for_selection = TRUE, $status = 1,$whr ="") {
        if ($branchid != 0) {
            $this->db->where(array("BranchID" => $branchid));
        }
        
        if ($status) {
            $this->db->where(array("Status" => $status));
        }
        if($whr!=""){
            $this->db->where($whr,NULL,FALSE);          
        }
        $query = $this->db->select()->from($table)->order_by($sort_col);
        $result = $query->get()->result();
        if (!$for_selection) {
            return $result;
        } else {
            $return_list = array();
            foreach ($result as $value) {
                $return_list[$value->$vkey] = $value->$skey;
            }
            return $return_list;
        }
    }
    public function add_common_fields($FormData){
        global $data;
        $FormData['Add_User'] = $data['Session_Data']['IBMS_USER_ID'];
        $FormData['Add_DateTime'] = date(ADD_DTF, time());
        return $FormData;
    }
   
    public function add_mode_user($FormData){
        global $data;
        $FormData['Mode_User'] = $data['Session_Data']['IBMS_USER_ID'];
        return $FormData;
    }
    public function unset_array($main_array, $key_to_unset) {
        foreach ($key_to_unset as $key) {
            if (isset($main_array[$key])) {
                unset($main_array[$key]);
            }
        }
        return $main_array;
    }
    public function is_auth_for_this(){
        global $data;
        $con = $data['cnf'][0];
        $fun = $data['cnf'][1];
        $BranchID = $data['Session_Data']['IBMS_BRANCHID'];
        $UTID = $data['Session_Data']['IBMS_USER_TYPE'];
        $sql = "SELECT ma.MID,(select menu.menu_title from ".DB_PREFIX."menus menu where menu.MID=ma.MID) as menu_title FROM `".DB_PREFIX."menu_access` ma WHERE ma.`MID` = (select MID from ".DB_PREFIX."menus nm where controller='$con' and function='$fun') and ma.BranchID=$BranchID and ma.UTID=$UTID and ma.`Allowed`=1";
        $query = $this->db->query($sql);
        $result = $query->result();
        if(empty($result)){
            return array("auth"=>FALSE);
        }else{
            return array("auth"=>FALSE,"title"=>$result[0]->menu_title);
        }
    }
 public function ShowMenus($PID = 0, $BranchID = '', $UTID = '',$only_Allowed=0,$only_menu=0) {
        $List = array();
        $this->db->select(array(DB_PREFIX . 'menus.*',
            DB_PREFIX . 'menu_access.UTID',
            DB_PREFIX . 'menu_access.Allowed'
        ));
        $this->db->from(DB_PREFIX . 'menus');
        $this->db->join(DB_PREFIX . "menu_access", DB_PREFIX . 'menus.MID' . "=" . DB_PREFIX . 'menu_access.MID', "RIGHT");
        $this->db->where(array(DB_PREFIX . "menu_access.BranchID" => $BranchID,DB_PREFIX . "menus.Status"=>1, DB_PREFIX . "menus.parent_id" => $PID, DB_PREFIX . 'menu_access.UTID' => $UTID));
        if($only_Allowed){
            $this->db->where(array(DB_PREFIX . 'menu_access.Allowed' => $only_Allowed));
        }
        if($only_menu){
            $this->db->where(array(DB_PREFIX . 'menus.is_menu' => 1));
        }
        $this->db->order_by(DB_PREFIX . 'menus.sort_order', 'ASC');
        $result = $this->db->get();
        $this->db->last_query();

        foreach ($result->result_array() as $mrow) {

            $List[] = array('Parent' => $mrow, 'Child' => $this->ShowMenus($mrow['MID'], $BranchID, $UTID,$only_Allowed));
        }

        return $List;
    }
     public function check_aready_exits($table,$where_array,$result_set = FALSE){
            $result = $this->db->get_where($table, $where_array);
            if($result_set)
                return $result->result();
            return $result->num_rows;       
           
    }
    public function get_a_column_value($get_column,$table,$where){
                  $query = $this->db->get_where($table,$where);  
                  $result = $query->result();
                  return $result[0]->$get_column;
    }
    public function update_data($table,$data,$where_array){
                  $this->db->where($where_array);
                  $this->db->update($table,$data);
                  return $this->db->affected_rows();
    }
}
