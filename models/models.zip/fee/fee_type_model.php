<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of Fee_Type
 *
 * @author Mr. Anup
 */
class fee_type_model extends CI_Model {

    function __construct() {
        parent::__construct();
    }

    public function all_Fee_Type_list() {
 // for all fee type list 
        $query = $this->db->select()->from("nexgen_fee_type_mst")->order_by('FeeType_Name');
        $result = $query->get()->result();
        return $result;
    }
public function all_Fee_Type_list_for_dropdown() {
         // for dropdown result
         $query = $this->db->select()->from("nexgen_fee_type_mst")->where(array("Status"=>1));
        $result = $query->get()->result();
        $fee_type_list=array();
        foreach ($result as $value) {
            $fee_type_list["{$value->FeeType_Code}"] = $value->FeeType_Name;
        }
        return $fee_type_list;
    }
   
   
    function Fee_Types_save_update() {
        $Fee_Type_form_data = array();
        try {
            
            foreach ($_POST as $key => $value) {
                $Fee_Type_form_data["$key"] = "";
                $Fee_Type_form_data["$key"] = $this->db->escape_str($value);
            }
            if ($Fee_Type_form_data["Add_Fee_Type"] === "Save") {
                 $this->db->select('*')->from('nexgen_fee_type_mst')->where(array("FeeType_Code" => $Fee_Type_form_data['FeeType_Code']));
             if($this->db->count_all_results()){
                 return array(FALSE,$Fee_Type_form_data['FeeType_Code']."  Fee Type Aready Exist");
             }
                $data_to_insert = $this->Fee_Type_query_string($Fee_Type_form_data);
                if ($this->db->insert("nexgen_fee_type_mst", $data_to_insert)) {
                    return array(TRUE);
                } else {
                    return array(FALSE);
                }
            } else {
                $data_to_update = $this->Fee_Type_query_string($Fee_Type_form_data);
                $this->db->where('FeeType_Code', $Fee_Type_form_data['Old_FeeType_Code']);
                if ($this->db->update("nexgen_fee_type_mst", $data_to_update)) {
                    return array(TRUE,course_encode($data_to_update['FeeType_Code']));
                } else {
                    return array(FALSE,course_encode($Fee_Type_form_data['Old_FeeType_Code']));
                }
            }
        } catch (Exception $ex) {
            return array(FALSE);
        }
    }

    public function Fee_Type_query_string($Fee_Type_form_data) {
        $data_to_insert_or_update = array(
            "FeeType_Code" =>$Fee_Type_form_data['FeeType_Code'],
            "FeeType_Name"=>$Fee_Type_form_data['FeeType_Name'],
            "Add_User" => $Fee_Type_form_data['Add_User'],
            "Mode_User" => $Fee_Type_form_data['Mode_User'],
            "Company" => $Fee_Type_form_data['Company'],
            "Status"=>$Fee_Type_form_data['Status'],
            "Branch" => $Fee_Type_form_data['Branch'],
            "Remarks" => $Fee_Type_form_data['Remarks']);
        return $data_to_insert_or_update;
    }
         public function get_details_from_database($FeeType_Code=''){
          $query = $this->db->get_where('nexgen_fee_type_mst',array("FeeType_Code"=>$FeeType_Code));
          if($this->db->count_all_results()>0){
          $Fee_Type_details =$query->first_row();
          return $Fee_Type_details; //sending first row
          }else{
              return FALSE;
          }
     }
      public function Del_FeeType($FeeType_Code){
        if($this->db->delete('nexgen_fee_type_mst', array('FeeType_Code' => $FeeType_Code))){
            return TRUE;
        }else{
            return FALSE;
        }
    }
}
