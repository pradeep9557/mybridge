<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of qualification
 * @author Mr. Anup
 */
class fee_collect_model extends CI_Model {

    function __construct() {
        parent::__construct();
    }

    public function check_fee_plan_setted($EnrollNo) {
        $query = $this->db->get_where("nexgen_scnb", array("EnrollNo" => $EnrollNo));
        $stu_details = $query->first_row();
        if ($stu_details->Fee_Plan_Setted) {
            return TRUE;
        } else {
            return FALSE;
        }
    }

    public function Fee_collect_save_update($All_Fee_Form_Data) {
        $insert_update_flag = FALSE;
        if ($All_Fee_Form_Data['Fee_Collect'] == "Save") {
            if ($All_Fee_Form_Data['PaidAmt'] == 0 || $All_Fee_Form_Data['NetPayableAmt'] == 0 || $All_Fee_Form_Data['TotalAmt'] == 0) {
                $cookie_data = array(array(
                        'cname' => '_err_msg',
                        'cvalue' => "Sorry Invalid Fee transaction, Total Amount, Paid Amount and Netpayable Can't be zero !!"
                ));
                $this->util_model->_set_encrypt_cookie($cookie_data);
                return array(FALSE);
                //return array(FALSE, "Sorry Invalid Fee transaction, Total Amount, Paid Amount and Netpayable Can't be zero !!");
            } else {
                if ($All_Fee_Form_Data['PaidAmt'] > $All_Fee_Form_Data['NetPayableAmt']) {
                    $cookie_data = array(array(
                            'cname' => '_err_msg',
                            'cvalue' => "Sorry Invalid Fee transaction, Paid Amount Can't be more then Net Payable Amount !! "
                    ));
                    $this->util_model->_set_encrypt_cookie($cookie_data);
                    return array(FALSE);
                    //return array(FALSE, "Sorry Invalid Fee transaction, Paid Amount Can't be more then Net Payable Amount !! "); 
                }
            }
//                if ($All_Fee_Form_Data['Individual_fee_plan_id'] == 0 && $All_Fee_Form_Data['FeeType_Code'] != "Bal") {
//                    return array(FALSE, "Sorry Invalid Fee type !! It Should be Balance");
//                }
            if ($All_Fee_Form_Data['MonthlyChargeAmt'] == 0 && $All_Fee_Form_Data['FeeType_Code'] == "Monthly") {
                $cookie_data = array(array(
                        'cname' => '_err_msg',
                        'cvalue' => "Sorry Invalid Fee type !! Fee Type Can't be Monthly Becuase Monthly Fee is Zero "
                ));
                $this->util_model->_set_encrypt_cookie($cookie_data);
                return array(FALSE);
                //return array(FALSE, "Sorry Invalid Fee type !! Fee Type Can't be Monthly Becuase Monthly Fee is Zero ");
            }
            $data_to_insert = $this->fee_query_insert_update($All_Fee_Form_Data);
            if ($this->db->insert("nexgen_fee_trn", $data_to_insert)) {
                $insert_update_flag = TRUE;
                // $data_to_update = $this->update_query_for_nexgen_scnb($All_Fee_Form_Data);
//                if ($this->db->update("nexgen_scnb", $data_to_update, array("EnrollNo" => $All_Fee_Form_Data['EnrollNo'], "CourseCode" => $All_Fee_Form_Data['CourseCode']))) {
//                    $insert_update_flag = TRUE;
                //$succ = FALSE;
//                    if($All_Fee_Form_Data['FeeType_Code']=="Bal"){ // if fee type is bal .. there there will not be any change in fee_plan installment
//                        if($this->db->query("update nexgen_scnb set Total_Bal=Total_Bal-{$All_Fee_Form_Data['PaidAmt']} where EnrollNo='{$All_Fee_Form_Data['EnrollNo']}' and CourseCode='{$All_Fee_Form_Data['CourseCode']}'")){
//                            $insert_update_flag = TRUE;
//                    }}else{
                if ($All_Fee_Form_Data['FeeType_Code'] != "Bal") {
                    if (isset($All_Fee_Form_Data['Individual_fee_plan_id']) && $All_Fee_Form_Data['Individual_fee_plan_id'] != "") {  // when all fee plan will be end then there will not any fee_plan_id so solution is to check it is defined or not    
                        if ($this->db->query("UPDATE  `nexgen_individual_fee_plan` SET  `Total_paid` =  `Total_paid` +1 WHERE ID ={$All_Fee_Form_Data['Individual_fee_plan_id']}"))
                            $insert_update_flag = TRUE;
                        else {
                            $insert_update_flag = FALSE;
                        }
                    }
                }
//                    }
            }
        } else if ($All_Fee_Form_Data['Fee_Collect'] == "Update") {
            $data_to_update = $this->fee_query_insert_update($All_Fee_Form_Data);
            $ID = $All_Fee_Form_Data['ID'];
//            $last_paid = $All_Fee_Form_Data['Old_PaidAmt'];
//            $Updated_paid = $All_Fee_Form_Data['PaidAmt'];
            // die();
            if ($this->db->update('nexgen_fee_trn', $data_to_update, array("ID" => $ID))) {
                $bal_amt = $All_Fee_Form_Data['BalanceAmt'];
                $old_bal_amt = $All_Fee_Form_Data['pre_bal'];
                $change_in_balance = $old_bal_amt - $bal_amt;
                $total_receipt = $this->fee_collect_model->get_no_of_installment($All_Fee_Form_Data['EnrollNo'], $All_Fee_Form_Data['CourseCode']);
                $total_receipt = $total_receipt - 1;
                if ($change_in_balance != 0 && $total_receipt > 1) {

                    $last_fee_recored = $this->fee_collect_model->last_fee_record($All_Fee_Form_Data['EnrollNo'], $All_Fee_Form_Data['CourseCode']);
                    if (!empty($last_fee_recored)) {
                        $data_to_update = array(
                            "OtherAmt" => ($last_fee_recored[0]->OtherAmt) - $change_in_balance,
                            "TotalAmt" => ($last_fee_recored[0]->TotalAmt) - $change_in_balance,
                            "BalanceAmt" => ($last_fee_recored[0]->BalanceAmt) - $change_in_balance,
                            "NetPayableAmt" => ($last_fee_recored[0]->NetPayableAmt) - $change_in_balance
                        );
                        if ($this->db->update('nexgen_fee_trn', $data_to_update, array("ID" => $last_fee_recored[0]->ID))) {
                            return array(TRUE, "");
                        } else {
                            return array(FALSE, "Error while updation of Last Fee Record !!");
                        }
                    }
                }
                //$sql = "update nexgen_scnb set Total_Paid_Amt=Total_Paid_Amt";
//                if ($last_paid < $Updated_paid)
//                    $sql.="+" . ($Updated_paid - $last_paid);
//                else if ($last_paid > $Updated_paid)
//                    $sql.="-" . ($last_paid - $Updated_paid);
//                $sql .= " , ";
                // for balance updation
//                $change_in_balance = $old_bal_amt - $bal_amt;
//                $sql.="update nexgen_scnb set `Total_Bal`=Total_Bal+ ($change_in_balance)";
//                if ($old_bal_amt < $bal_amt)
//                    $sql.="+" . ($bal_amt - $old_bal_amt);
//                else if ($old_bal_amt > $bal_amt)
//                    $sql.="-" . ($old_bal_amt - $bal_amt);
//                $sql.=" where EnrollNo='{$All_Fee_Form_Data['EnrollNo']}' and CourseCode='{$All_Fee_Form_Data['CourseCode']}'";
//                print_r($sql);
//                if ($this->db->simple_query($sql)) {
//                    $insert_update_flag = TRUE;
//                }
            } else {
                return array($insert_update_flag, "Error In Fee Updation");
            }
        }
        return array($insert_update_flag, "Neither Update Nor Save selected !!");
    }

    public function fee_query_insert_update($All_Fee_Form_Data) {
        $data_to_insert_update = array(
            "FeeType_Code" => $All_Fee_Form_Data['FeeType_Code'],
            "EnrollNo" => $All_Fee_Form_Data['EnrollNo'],
            "ReceiptDate" => date(DB_DF, strtotime($All_Fee_Form_Data['ReceiptDate'])),
            "CourseCode" => $All_Fee_Form_Data['CourseCode'],
            "Month" => $All_Fee_Form_Data['Month'],
            "RegFeeAmt" => $All_Fee_Form_Data['RegFeeAmt'],
            "MonthlyChargeAmt" => $All_Fee_Form_Data['MonthlyChargeAmt'],
            "LatePaymentAmt" => $All_Fee_Form_Data['LatePaymentAmt'],
            "StudyMaterialCostAmt" => $All_Fee_Form_Data['StudyMaterialCostAmt'],
            "ExamFeeAmt" => $All_Fee_Form_Data['ExamFeeAmt'],
            "ProspectusCostAmt" => $All_Fee_Form_Data['ProspectusCostAmt'],
            "OtherAmt" => $All_Fee_Form_Data['OtherAmt'],
            "TotalAmt" => $All_Fee_Form_Data['TotalAmt'],
            "DisAmt" => $All_Fee_Form_Data['DisAmt'],
            "FacultyCode" => $All_Fee_Form_Data['FacultyCode'],
            "BatchCode" => $All_Fee_Form_Data['BatchCode'],
            "NetPayableAmt" => $All_Fee_Form_Data['NetPayableAmt'],
            "PaidAmt" => $All_Fee_Form_Data['PaidAmt'],
            "BalanceAmt" => $All_Fee_Form_Data['BalanceAmt'],
            "BalDueDate" => date(DB_DF, strtotime($All_Fee_Form_Data['BalDueDate'])),
            "BalanceDetail" => $All_Fee_Form_Data['BalanceDetail'],
            "NextInstAmt" => $All_Fee_Form_Data['NextInstAmt'],
            "AfterNextInstAmt" => $All_Fee_Form_Data['AfterNextInstAmt'],
            "NoOfInstallment" => $All_Fee_Form_Data['NoOfInstallment'],
            "NextDueDate" => date(DB_DF, strtotime($All_Fee_Form_Data['NextDueDate'])),
            "AfterNextDueDate" => date(DB_DF, strtotime($All_Fee_Form_Data['AfterNextDueDate'])),
            "Remarks" => $All_Fee_Form_Data['Remarks'],
            "Add_User" => $All_Fee_Form_Data['Add_User'],
            "Individual_fee_plan_id" => $All_Fee_Form_Data['Individual_fee_plan_id'],
            "Mode_User" => $All_Fee_Form_Data['Mode_User']);

        return $data_to_insert_update;
    }

    public function total_installments_amount($EnrollNo, $CourseCode) {
        $this->db->select_sum('TotalAmt')->where(array("EnrollNo" => $EnrollNo, "CourseCode" => $CourseCode));
        $q = $this->db->get('nexgen_fee_trn');
        $result = $q->result();
        return $result[0]->TotalAmt;
    }

    public function save_update_fee_plan($all_Fee_plan_form_data) {
        $insert_update_flag = FALSE;
        $minimum_total = 0;
        if ($all_Fee_plan_form_data['Add_indi_fee_paln'] == "Save") {
            for ($index = 1; $index <= $all_Fee_plan_form_data['total_row']; $index++) {
                $data_to_insert = $this->fee_plan_query($all_Fee_plan_form_data, $index);
                if ($this->db->insert("nexgen_individual_fee_plan", $data_to_insert)) {
                    $insert_update_flag = TRUE;
                    // $minimum_total += $data_to_insert['Inst_amt'] * $data_to_insert['Total_Inst'];
                } else {
                    $insert_update_flag = FALSE;
                }
            }
//            if ($insert_update_flag) {
//                $sql = "update nexgen_scnb set Fee_Plan_Setted=1,Minimum_Total = Minimum_Total+$minimum_total where EnrollNo='{$all_Fee_plan_form_data['EnrollNo1']}' and CourseCode='{$all_Fee_plan_form_data['CourseCode1']}'";
//                if (!$this->db->query($sql))
//                    $insert_update_flag = FALSE;
//            }
        } else if ($all_Fee_plan_form_data['Add_indi_fee_paln'] == "Update") {
            $Fee_Plan_ID = $_POST['Fee_Plan_ID'];
            $Fee_Plan_Details = $this->Get_Fee_Plan_Details_via_ID($Fee_Plan_ID);
            $old_Total_Inst = $Fee_Plan_Details[0]->Total_Inst;
            $Total_paid = $Fee_Plan_Details[0]->Total_paid;
            $old_Inst_amt = $Fee_Plan_Details[0]->Inst_amt;
            $EnrollNo = $Fee_Plan_Details[0]->EnrollNo;
            $CourseCode = $Fee_Plan_Details[0]->CourseCode;
            /*
             * It will find the changes, might be user can increase the installment amount or descrase
             * on that behalf we will fetch the last receipt no and and increaes the balance amount.             * 
             */
            $new_Inst_amt = $_POST['Inst_amt1'];
            $new_Total_Inst = $_POST['Total_Inst1'];
            if ($new_Total_Inst < $Total_paid) {
                return FALSE;
            }
            if ($old_Inst_amt == $new_Inst_amt && $old_Total_Inst == $new_Total_Inst) {
                return TRUE;
            } else if ($Total_paid == 0) {
                $data_to_update = array("Inst_amt" => $new_Inst_amt, "Total_Inst" => $new_Total_Inst);
                if ($this->db->update("nexgen_individual_fee_plan", $data_to_update, array("ID" => $Fee_Plan_ID))) {
                    $insert_update_flag = TRUE;
                }
            } else if ($Total_paid != 0 && $old_Inst_amt == $new_Inst_amt) {
                $data_to_update = array("Total_Inst" => $new_Total_Inst);
                if ($this->db->update("nexgen_individual_fee_plan", $data_to_update, array("ID" => $Fee_Plan_ID))) {
                    $insert_update_flag = TRUE;
                }
            } else {
                $this->db->order_by('ID', 'ASC');
                $q = $this->db->get_where("nexgen_fee_trn", array("Individual_fee_plan_id" => $Fee_Plan_ID));
                $Fee_taken_from_this_Fee_plan = $q->result();
                $Receipt_no_taken = array();
                $index = 0;
                $First_Receipt_from_this_plan = 0;
                foreach ($Fee_taken_from_this_Fee_plan as $Fee_trn_Row) {
                    if ($First_Receipt_from_this_plan == 0) {
                        $First_Receipt_from_this_plan = $Receipt_no_taken[$index++] = $Fee_trn_Row->ID;
                    } else {
                        $Receipt_no_taken[$index++] = $Fee_trn_Row->ID;
                    }
                }
                $bal_to_increase_descrase = 0;
                $change_in_monthly_fee = $new_Inst_amt - $old_Inst_amt;
                // it will update in all receipt which taken after this fee plan or with this fee plan ..
                // to remove abnormal data

                $this->db->select('*')->from('nexgen_fee_trn');
                $this->db->where("ID>=$First_Receipt_from_this_plan", NULL, FALSE);
                $this->db->where(array("EnrollNo" => $EnrollNo, "CourseCode" => $CourseCode));
                $this->db->order_by('ID', 'ASC');
                $q2 = $this->db->get();
                $All_abnormal_fee_receipt = $q2->result();
                $i = 0; // for change the monthly fee with taken form above fee plan
                $BalanceAmt = 0;
                foreach ($All_abnormal_fee_receipt as $Receipt) {
                    if ($Receipt_no_taken[$i] == $Receipt->ID) {
                        $i++;
                        $bal_to_increase_descrase += $change_in_monthly_fee;
                        $MonthlyChargeAmt = $Receipt->MonthlyChargeAmt + ($change_in_monthly_fee);
                        $TotalAmt = $Receipt->TotalAmt + $bal_to_increase_descrase;
                        $BalanceAmt = $Receipt->BalanceAmt + $bal_to_increase_descrase;

                        $data_to_update = array(
                            "MonthlyChargeAmt" => $MonthlyChargeAmt,
                            "BalanceAmt" => $BalanceAmt,
                            "TotalAmt" => $TotalAmt
                        );
                        if (!$this->db->update('nexgen_fee_trn', $data_to_update, array("ID" => $Receipt->ID))) {
                            $insert_update_flag = FALSE;
                        }
                    } else {
                        $BalanceAmt = $Receipt->BalanceAmt + ($bal_to_increase_descrase);
                        $TotalAmt = $Receipt->TotalAmt + $bal_to_increase_descrase;
                        //       $bal_to_increase_descrase += $BalanceAmt;
                        $data_to_update = array(
                            "BalanceAmt" => $BalanceAmt,
                            "TotalAmt" => $TotalAmt);
                        if (!$this->db->update('nexgen_fee_trn', $data_to_update, array("ID" => $Receipt->ID))) {
                            $insert_update_flag = FALSE;
                        }
                    }
                }

                $data_to_update = array("Inst_amt" => $new_Inst_amt, "Total_Inst" => $new_Total_Inst);
                if ($this->db->update("nexgen_individual_fee_plan", $data_to_update, array("ID" => $Fee_Plan_ID))) {
                    $insert_update_flag = TRUE;
                }
            }
        }
        return $insert_update_flag;
    }

    public function fee_plan_query($all_Fee_plan_form_data, $index) {
        $data_to_insert_or_update = array(
            "EnrollNo" => strtoupper($all_Fee_plan_form_data['EnrollNo' . $index]),
            "CourseCode" => $all_Fee_plan_form_data['CourseCode' . $index],
            "Inst_amt" => $all_Fee_plan_form_data['Inst_amt' . $index],
            "Total_Inst" => $all_Fee_plan_form_data['Total_Inst' . $index],
            "Remarks" => $all_Fee_plan_form_data['Remarks' . $index],
            "Add_User" => $all_Fee_plan_form_data['Add_User'],
            "Mode_User" => $all_Fee_plan_form_data['Mode_User']
        );
        return $data_to_insert_or_update;
    }

    public function All_fee_plan_of_student($EnrollNo, $CourseCode) {
        $this->db->order_by('ID');
        $query = $this->db->get_where("nexgen_individual_fee_plan", array("EnrollNo" => $EnrollNo, "CourseCode" => $CourseCode));
        $all_stu_scnb_details = $query->result();
        return $all_stu_scnb_details;
    }

    function Data_to_print_fee($Receipt_NO) {
        $sql = "SELECT t1.`ID`,t1.`ReceiptDate`,t1.`FeeType_Code`,t1.`EnrollNo`,t1.`CourseCode`,t1.`BatchCode`,t1.Month,
t1.`FacultyCode`, t1.`RegFeeAmt`,t1.`RegFeeAmt`, t1.`MonthlyChargeAmt`, t1.`LatePaymentAmt`, t1.`StudyMaterialCostAmt`,
t1.`ExamFeeAmt`, t1.`ProspectusCostAmt`, t1.`OtherAmt`, t1.`TotalAmt`, t1.`DisAmt`, t1.`NetPayableAmt`,
t1.`PaidAmt`, t1.`BalanceAmt`, t1.`BalDueDate`, t1.`BalanceDetail`, t1.`NextInstAmt`, 
t1.`AfterNextInstAmt`, t1.`NoOfInstallment`, t1.`NextDueDate`, t1.`AfterNextDueDate`, 
t1.`Remarks`, t1.`Add_User`, t1.`Mode_User`,t2.`Due_Date`,t3.Start_Time,t3.End_Time,t4.Duration,
t4.MonthDay, lf.Late_Payment_Fee,lf.Website,lf.Address1,lf.Email,t5.DOR,t5.StudentName,t5.FatherName
,t5.C_houseno,t5.C_street,t5.C_city,t5.C_village_and_post,t5.Mobile1
FROM nexgen_late_fine lf,  `nexgen_fee_trn` t1 INNER JOIN nexgen_scnb t2 
ON(t1.`CourseCode`=t2.`CourseCode` and t1.`EnrollNo`=t2.`EnrollNo`) INNER JOIN  nexgen_batch_master t3 ON(t1.BatchCode=t3.BatchCode and t1.FacultyCode=t3.FacultyCode) INNER JOIN nexgen_course_mst t4 ON (t1.`CourseCode`=t4.`CourseCode`) INNER JOIN nexgen_student_mst t5 ON (t1.EnrollNo=t5.EnrollNo) WHERE t1.`ID`=$Receipt_NO";
        $q = $this->db->query($sql);
        return $q->result();
    }

    public function is_record_exits_in_fee_plan_table($EnrollNo, $CourseCode) {
        $q = $this->db->select('*')->from('nexgen_individual_fee_plan')->where(array("EnrollNo" => $EnrollNo, "CourseCode" => $CourseCode));
        if ($this->db->count_all_results()) {
            return TRUE;
        } else {
            return FALSE;
        }
    }

    public function Get_Fee_Plan_Details_via_ID($ID) {
        $query = $this->db->get_where("nexgen_individual_fee_plan", array('ID' => $ID));
        return $query->result();
    }

    public function Del_Fee_plan($ID) {
        $result = $this->Get_Fee_Plan_Details_via_ID($ID);
        if ($result[0]->Total_paid > 0) {
            return FALSE;
        } else {
//        $amount_to_less = $result[0]->Inst_amt * $result[0]->Total_Inst;
//        $sql = "update nexgen_scnb set Minimum_Total = Minimum_Total- $amount_to_less where EnrollNo='{$result[0]->EnrollNo}' and CourseCode='{$result[0]->CourseCode}'";
            // if ($this->db->query($sql)) {
            if ($this->db->delete('nexgen_individual_fee_plan', array('ID' => $ID))) {
                return TRUE;
            } else {
                return FALSE;
            }
        }
    }

//    public function Del_Fee_record($ID) {
//        $del_flag = FALSE;
//        $query = $this->db->get_where("nexgen_fee_trn", array('ID' => $ID));
//        $result = $query->result();
//        $individual_fee_plan_id = "";
//        $amount_to_less = $result[0]->PaidAmt;
//        $MonthlyChargeAmt = $result[0]->MonthlyChargeAmt;
//        $sql = "update nexgen_scnb set Total_Paid_Amt = Total_Paid_Amt- $amount_to_less  where EnrollNo='{$result[0]->EnrollNo}' and CourseCode='{$result[0]->CourseCode}'";
//        if ($this->db->query($sql)) { 
//        // // to reduce the paid amount .. becuase deleting the wrong receipt so total paid should be --
//            // and number of paid installments .. 
//            if ($result[0]->FeeType_Code != "Bal") {
//                $query = $this->db->get_where('nexgen_individual_fee_plan', array('Inst_amt' => $MonthlyChargeAmt));
//                $result_fee_plan = $query->result();
//                if (!empty($result_fee_plan[0])) {
//                    $individual_fee_plan_id = $result_fee_plan[0]->ID;
//                } else {
//                    $query = $this->db->get_where('nexgen_individual_fee_plan', array('EnrollNo' => $result[0]->EnrollNo, "CourseCode" => $result[0]->CourseCode));
//                    $this->db->order_by('ID');
//                    $last = $query->last_row();
//                    $individual_fee_plan_id = $last->ID;
//                }
//                $sql = "update nexgen_individual_fee_plan set Total_Paid = Total_Paid-1  where ID='$individual_fee_plan_id'";
//                if ($this->db->query($sql)) {
//                    $this->db->where(array('ID' => $ID));
//                    if ($this->db->delete('nexgen_fee_trn'))
//                        $del_flag = TRUE;
//                }
//                if ($result[0]->BalanceAmt != 0) {
//                    if (!$this->db->query("update nexgen_scnb set `Total_Bal`=Total_Bal-{$result[0]->BalanceAmt} where `EnrollNo`='" . $result[0]->EnrollNo . "' and  `CourseCode`='" . $result[0]->CourseCode . "'"))
//                        $del_flag = FALSE;
//                }
//            }else {
//                if ($this->db->query("update nexgen_scnb set `Total_Bal`=Total_Bal+{$result[0]->PaidAmt} where `EnrollNo`='" . $result[0]->EnrollNo . "' and  `CourseCode`='" . $result[0]->CourseCode . "'")) {
//                    $del_flag = TRUE;
//                } else {
//                    $del_flag = FALSE;
//                }
//            }
//        }
//        if (!$this->db->delete('nexgen_fee_trn', array('ID' => $ID)))
//            $del_flag = FALSE;
//        return $del_flag;
//    }

    public function all_fee_records($EnrollNo) {
        $this->db->select('*')->from("nexgen_fee_trn")->where(array("EnrollNo" => $EnrollNo))->order_by('ID,CourseCode', 'ASC');
        $query = $this->db->get();
        $all_fee_records = $query->result();
        return $all_fee_records;
    }

    public function all_fees_record() {
        $this->db->select('*')->from("nexgen_fee_trn")->order_by('Mode_DateTime,CourseCode', 'DESC');
        $query = $this->db->get();
        $all_fee_records = $query->result();
        return $all_fee_records;
    }

    public function get_no_of_installment($EnrollNo, $CourseCode) {
        $this->db->select('*')->from('nexgen_fee_trn')->where(array('EnrollNo' => $EnrollNo, 'CourseCode' => $CourseCode));
        return $this->db->count_all_results() + 1;
    }

    public function all_fee_records_from_receipt_number($receipt_number) {
        $this->db->select('*')->from("nexgen_fee_trn")->where(array("ID" => $receipt_number));
        $query = $this->db->get();
        $fee_records = $query->result();
        return $fee_records;
    }

    public function last_fee_record($EnrollNo, $CourseCode,$FeeType_Code='') {
        if($FeeType_Code!=""){
             $this->db->order_by('ID', 'DESC');
                $query = $this->db->get_where("nexgen_fee_trn", array("EnrollNo" => $EnrollNo, "CourseCode" => $CourseCode,"FeeType_Code"=>$FeeType_Code));
                $all_stu_scnb_details = $query->result();
                return $all_stu_scnb_details;
        }else
        if ($EnrollNo != "") {
            if ($CourseCode != "") {
                $this->db->order_by('ID', 'DESC');
                $query = $this->db->get_where("nexgen_fee_trn", array("EnrollNo" => $EnrollNo, "CourseCode" => $CourseCode));
                $all_stu_scnb_details = $query->result();
                return $all_stu_scnb_details;
            } else {
                $this->db->select('*')->from("nexgen_fee_trn")->where(array("EnrollNo" => $EnrollNo))->order_by('ID', 'DESC')->limit('1');
                $query = $this->db->get();
                return $query->result();
            }
        } else {
            return FALSE;
        }
    }

    public function this_month_collection() {
        $start_date = date("Y", time()) . "-" . date("m", time()) . "-01";
        $today = date("Y-m-d", time());
        $this->db->select_sum("PaidAmt", "total_Paid_amount")->from("nexgen_fee_trn");
        $where = "ReceiptDate<= '$today' AND ReceiptDate>= '$start_date'";
        $this->db->where($where, NULL, FALSE);
        $query = $this->db->get();
        $result = $query->result();
//        if ($this->db->count_all_results() == 1) {
//            return 0;
//        } else {
        return $result[0]->total_Paid_amount;
//        }
    }

}
