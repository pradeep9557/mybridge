<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of m_menu
 *
 * @author kuldeep
 */
class usertypes_model extends CI_Model {

    //put your code here
    public function __construct() {
        parent::__construct();
    }

    function form_validation($POST) {
        $err_codes = '';
        if (isset($POST['UserType']) && $POST['UserType'] == "") {
            $err_codes.='U_TypeBlank' . ERR_DELIMETER;
        }
        $valid = $err_codes == '' ? TRUE : FALSE;
        return array("_err" => $valid, "_err_codes" => $err_codes);
    }

    public function AddUserType($FormData) {
        global $data;
        $this->load->helper('array');
        $this->load->model('super-admin/m_menu');
        $validates = $this->form_validation($FormData);
        if (!$validates['_err']) {
            return array("succ" => false, "_err_codes" => $validates['_err_codes']);
        }
        $data_to_insert = $FormData;
        $data_to_insert = $this->util_model->unset_array($FormData, array('BranchID'));
        $succ = $this->db->insert(DB_PREFIX . 'usertypes', $data_to_insert);
        $UTID = $this->db->insert_id();
        $branches = $FormData['BranchID'];
        $all_menu_list = $this->m_menu->all_menu();
        $menu_access_to_insert = array();
        $branch_access = array();
        foreach ($branches as $BranchID) {
            // Creating array for branch access 
            $branch_access[] = array( 
                "BranchID" => $data['Session_Data']['IBMS_BRANCHID'],
                "UTID" => $UTID,
                "AccessBranchID" => $BranchID,
                "Status" => 1,
                "Add_User" => $FormData['Add_User'],
                "Add_DateTime" => $FormData['Add_DateTime']
            );
            // creating array for menu access
            foreach ($all_menu_list as $menu_obj) {
                $menu_access_to_insert[] = array(
                    "BranchID" => $BranchID,
                    "UTID" => $UTID,
                    "MID" => $menu_obj->MID
                );
            }
        }
        if ($this->db->insert_batch(DB_PREFIX . "branch_access", $branch_access) &&
            $this->db->insert_batch(DB_PREFIX . "menu_access", $menu_access_to_insert)) {
            return array("succ" => false, "_err_codes" => "UTAddedSucc" . ERR_DELIMETER);
        } else {
            return array("succ" => false, "_err_codes" => "MAddErr" . ERR_DELIMETER);
        }
       
    }

    public function AllUserTypes() {
        $this->db->select("t1.UTID,t1.UserTypeName,t1.Status,t1.Sort,t3.Emp_Code as Add_User,t4.Emp_Code as Mode_User,t1.Add_DateTime,t1.Mode_DateTime")->from(DB_PREFIX . "usertypes as t1");
        $this->db->join(DB_PREFIX . "employee t3", "t1.Add_User=t3.Emp_ID", 'LEFT');
        $this->db->join(DB_PREFIX . "employee t4", "t1.Mode_User=t4.Emp_ID", 'LEFT')->where(array("t1.Status" => 1));
        return $this->db->get()->result();
    }

    public function AllUserTypeForSelect() {
        /*

         * used by 
         * auth/login
         *          */
        $this->db->select("UTID,UserTypeName");
        $this->db->from(DB_PREFIX . 'usertypes')->where(array("Status" => 1))->order_by("Sort");
        $UserTypeList;
        foreach ($this->db->get()->result_array() as $UT_row) {
            $UserTypeList[$UT_row['UTID']] = $UT_row['UserTypeName'];
        }
        return $UserTypeList;
    }

    public function AllUsers($BranchID = 1, $UTID = 0) {
        $List = array();
        $this->db->select('Emp_ID,Emp_Code,Emp_Name');
        $this->db->from(DB_PREFIX . 'employee');
        $this->db->where(array('Status' => '1'));
        if ($UTID != 0) {
            $this->db->where(array("UTID" => $UTID));
        }
        if ($BranchID != 0) {
            $this->db->where(array('BranchID' => $BranchID));
        }
        foreach ($this->db->get()->result_array() as $User) {

            $List[$User['Emp_ID']] = $User['Emp_Name'] . "({$User['Emp_Code']})";
        }
        return $List;
    }

}
