<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of manage_tasks
 * @Created on : 27 May, 2016, 2:03:06 PM
 * @author Deepak Singh
 * @Team NexGen PHP Development Team
 * @copyright (c) year, NexGen Innovators IT Services Pvt. Ltd.
 * @website http://nexgeninnovators.com
 * @location
 * @Use
 * 
 */
class manage_tasks extends CI_Controller {

    // constructor
    public function __construct() {
        // calling to parent constructor
        parent::__construct();
        $this->load->model("tms/m_task_manage", 'm_task');
    }

    // start you function from here
    public function index($task_id = "", $error = '', $_err_codes = '') { //provide a view of new Employee form
        global $data;
        $data = $this->util_model->set_error($data, $error, $_err_codes);

        $this->load->library("ajax/tms_ajax.php");
        $data['task_search_for'] = "Tasks";

        $data['user_types'] = $this->util_model->get_list("UTID", "UserTypeName", DB_PREFIX . "usertypes");
        unset($data['user_types'][1]);
        //To list all the nationality from the database 
        $data['days_list'] = $this->util_model->days_list();
        if (!file_exists(APPPATH . '/views/tms/manage_tasks/v_add_task.php')) {
            show_404();
        }
        $data['tm_id'] = $task_id;

        if ($task_id != "" && $task_id != STATUS_FALSE && $this->util_model->get_column_value("status", DB_PREFIX . "task_mst", array("tm_id" => $data['tm_id'])) != "") {
            $data['task_data'] = $this->m_task->fetch_task_data($task_id);
            $data['helper_task_list'] = $this->util_model->get_column_value("parent_ttmid", DB_PREFIX . "task_type_mst", array("ttm_id" => $data['task_data']['ttm_id']));
            $data['ttm_ids'] = $this->m_task->fetch_ttm_id($data['helper_task_list']);
        } else {
            $data['task_search_view'] = $this->tms_ajax->task_search(array("collapse" => 1));
        }

        $data['under'] = array("0" => "Parent Category") + $this->util_model->get_list("ttm_id", "ttm_name", DB_PREFIX . "task_type_mst", 0, "ttm_name", TRUE, 1, " parent_ttmid=0");
        $this->load->model('tms/m_manage_users');
        $data['incharge'] = array("0" => "Select Incharge") + $this->m_manage_users->get_users_for_create_task();
        $data['client_list'] = $this->m_manage_users->get_all_clients();
//        $this->util_model->printr($data['client_list']);
        $data['locality'] = array("0" => "Select Locality") + $this->util_model->get_list("localityid", "locality", DB_PREFIX . "locality", 0, "locality", TRUE, 1);

        if (!empty($_GET) && ($_GET['tab'] == "create_replica" || $_GET['tab'] == "copy_task")) {
            $data['active_tab'] = $_GET['tab'];
        }
        if (isset($data['active_tab']) && $data['active_tab'] == 'create_replica') {
            $data['title'] = "Replica Form";
        } else if (isset($data['active_tab']) && $data['active_tab'] == 'copy_task') {
            $data['title'] = "Duplicate Task Form";
        } else if ($data['tm_id'] != "" && !empty($data['task_data'])) {
            $data['title'] = "Edit Task";
        } else {
            $data['title'] = "New Task From";
        }

        $this->load->view('templates/header.php', $data);
        $this->load->view('templates/common_window_pop_up.php');

        $this->load->view('tms/manage_tasks/v_add_task.php', $data);
        $this->load->view('templates/footer.php');
    }

//    public function All_tasks_List() {
//        $data['Session_Data'] = $this->session->all_userdata();
//
//        $data['all_task_details'] = $this->m_task->getTasks();
//        if (!file_exists(APPPATH . '/views/tms/manage_tasks/v_all_task.php')) {
//            show_404();
//        }
//        $data['title'] = ucfirst("All Task List | " . SITE_NAME); //capitalizing the first character of string for header.
//        $this->load->view('tms/manage_tasks/v_all_task.php', $data);
//    }

    public function get_task_types() {
        $formdata = $this->input->post();
        $result = array("0" => "Select Type") + $this->util_model->get_list("ttm_id", "ttm_name", DB_PREFIX . "task_type_mst", 0, "ttm_name", TRUE, 1, " parent_ttmid=" . $formdata['ttm_id']);
        if (!empty($result)) {
            echo json_encode(array("succ" => TRUE, "data" => $result));
        } else {
            echo json_encode(array("succ" => FALSE));
        }
    }

    public function fetch_all_task_types() {
        $formdata = $this->input->post();
        $result = $this->m_task->get_task_data($formdata);
        if (!empty($result)) {
            echo json_encode(array("succ" => TRUE, "data" => $result));
        } else {
            echo json_encode(array("succ" => FALSE));
        }
    }

    public function convert_into_days($FormData) {
        if (isset($FormData['does_repeat']) &&
                $FormData['does_repeat'] &&
                isset($FormData['repeat_gap']) &&
                isset($FormData['repeat_unit'])) {
//            $FormData['repeat_unit'] = floor((strtotime("+{$FormData['repeat_unit']} {$FormData['repeat_gap']}") - strtotime(time())) / (60 * 60 * 24));
            $date1 = date_create(date("Y-m-d", strtotime("+{$FormData['repeat_unit']} {$FormData['repeat_gap']}")));
            $date2 = date_create(date("Y-m-d", strtotime("now")));
            $diff = date_diff($date1, $date2);
            $FormData['repeat_unit'] = $diff->format("%a");
        }
        return $FormData;
    }

    public function task_save_update() {
        $FormData = $this->input->post();
//        $this->util_model->printr($FormData);
//        die();
        $action = $FormData['action'];
        unset($FormData['action']);
        $result = array("succ" => FALSE);
        $FormData = $this->convert_into_days($FormData);
        $task_master_data = array(
            "skill_dev_activity"=>$FormData['skill_dev_activity'],
            "ttm_id" => $FormData['ttm_id'],
            "tm_name" => $FormData['tm_name'],
            "tm_code" => $FormData['tm_code'],
            "start_date" => date(DB_DTF, strtotime($FormData['start_date'])),
            "end_date" => date(DB_DTF, strtotime($FormData['end_date'])),
            "extra_note" => $FormData['extra_note'],
            "does_repeat" => $FormData['does_repeat'],
            "approx_exp" => $FormData['approx_exp'],
            "client_id" => $FormData['client_id'],
            "repeat_gap" => $FormData['repeat_gap'],
            "repeat_unit" => $FormData['repeat_unit'],
            "progress_flag" => IN_PROGRESS);

        if (!empty($FormData['tstm_id']) && $action == "update" && $FormData['action_performed'] == "update") {
            $result = $this->m_task->update_sub_task($task_master_data, $FormData);
        } else if (!empty($FormData['tstm_id']) && $action == "replica" && $FormData['action_performed'] == "update") {
            $this->replicate_task($task_master_data, $FormData);
        } else if (!empty($FormData['tstm_id']) && $action == "copy") {
            $this->copy_task($task_master_data, $FormData);
        } else {
//            echo "coming";
            $result = $this->m_task->create_sub_task($task_master_data, $FormData);
            if ($result['succ'] && $action != "update" && $action != "replica") {
                $this->db->select("DISTINCT(e.Emp_ID), e.Emp_Name,e.P_Email", null, FALSE)->from(DB_PREFIX . "task_mst as tm");
                $this->db->join(DB_PREFIX . "task_sub_task as tst", "tst.tm_id=tm.tm_id", 'left');
                $this->db->join(DB_PREFIX . "task_users as tu", "tu.tm_id=tm.tm_id", 'left');
                $this->db->join(DB_PREFIX . "employee as e", "e.Emp_ID=tst.assignedto or e.Emp_ID=tu.user_id", 'left');
                $this->db->where(array("tm.tm_id" => $result['id'], "tu.mail_notification" => STATUS_TRUE));
                $mail_result = $this->db->get()->result_array();
                $this->m_task->send_new_task_create_mail($mail_result, $result['id']);
            }
        }
        echo json_encode($result);
//  redirect(base_url() . "tms/manage_tasks/index/" . $result['id'] . "/" . ($result['succ'] ? "0/" . $result['_err_codes'] : "1/" . $result['_err_codes']));
    }

    public function replicate_task($task_master_data, $filter_data) {
        if (isset($filter_data['tm_id']) && $this->util_model->get_a_column_value("status", DB_PREFIX . "task_mst", array("tm_id" => $filter_data['tm_id'])) != "") {
            $tm_code = $this->m_task->get_task_code(array("task_name" => $filter_data['tm_code']));
            $task_master_data["tm_code"] = $tm_code['code'];
//            $this->util_model->printr($task_master_data);
//            die($this->util_model->printr($filter_data));
            $result = $this->m_task->replicate_sub_task($task_master_data, $filter_data);

            if ($result['succ']) {
                $this->db->select("DISTINCT(e.Emp_ID), e.Emp_Name,e.P_Email", null, FALSE)->from(DB_PREFIX . "task_mst as tm");
                $this->db->join(DB_PREFIX . "task_sub_task as tst", "tst.tm_id=tm.tm_id", 'left');
                $this->db->join(DB_PREFIX . "task_users as tu", "tu.tm_id=tm.tm_id", 'left');
                $this->db->join(DB_PREFIX . "employee as e", "e.Emp_ID=tst.assignedto or e.Emp_ID=tu.user_id", 'left');
                $this->db->where(array("tm.tm_id" => $result['id'], "tu.mail_notification" => STATUS_TRUE));
                $mail_result = $this->db->get()->result_array();
                $this->m_task->send_new_task_create_mail($mail_result, $result['id']);
            }
            echo json_encode($result);
            die();
//            redirect(base_url() . "tms/manage_tasks/index/" . $result['id'] . "/" . ($result['succ'] ? "0/" . $result['_err_codes'] : "1/" . $result['_err_codes']));
        } else {
            echo json_encode(array("succ" => FALSE, "_err_codes" => array("Invalid Task Code passed")));
            die();
//            redirect(base_url() . "tms/manage_tasks/index/" . $filter_data['tm_id'] . "/0/" . "TTIdError" . ERR_DELIMETER);
        }
    }

    public function copy_task($task_master_data, $filter_data) {
        if (isset($filter_data['tm_id']) && $this->util_model->get_a_column_value("status", DB_PREFIX . "task_mst", array("tm_id" => $filter_data['tm_id'])) != "") {
            $tm_code = $this->m_task->get_task_code(array("task_name" => $filter_data['tm_code']));
            $task_master_data["tm_code"] = $tm_code['code'];
//            $this->util_model->printr($task_master_data);
//            die($this->util_model->printr($filter_data));
            $result = $this->m_task->replicate_sub_task($task_master_data, $filter_data, TRUE);

            if ($result['succ']) {
                $this->db->select("DISTINCT(e.Emp_ID), e.Emp_Name,e.P_Email", null, FALSE)->from(DB_PREFIX . "task_mst as tm");
                $this->db->join(DB_PREFIX . "task_sub_task as tst", "tst.tm_id=tm.tm_id", 'left');
                $this->db->join(DB_PREFIX . "task_users as tu", "tu.tm_id=tm.tm_id", 'left');
                $this->db->join(DB_PREFIX . "employee as e", "e.Emp_ID=tst.assignedto or e.Emp_ID=tu.user_id", 'left');
                $this->db->where(array("tm.tm_id" => $result['id'], "tu.mail_notification" => STATUS_TRUE));
                $mail_result = $this->db->get()->result_array();
                $this->m_task->send_new_task_create_mail($mail_result, $result['id']);

                $result['_err_codes'] = array("Task Copied Successfully!!");
            } else {
                $result['_err_codes'] = array("Error while Copying Task!!");
            }

            echo json_encode($result);
            die();
//            redirect(base_url() . "tms/manage_tasks/index/" . $result['id'] . "/" . ($result['succ'] ? "0/" . $result['_err_codes'] : "1/" . $result['_err_codes']));
        } else {
            echo json_encode(array("succ" => FALSE, "_err_codes" => array("Invalid Task Code passed")));
            die();
//            redirect(base_url() . "tms/manage_tasks/index/" . $filter_data['tm_id'] . "/0/" . "TTIdError" . ERR_DELIMETER);
        }
    }

    public function All_replica_List() {
        global $data;
        $this->load->view('templates/header.php', $data);
        $this->load->library("ajax/tms_ajax.php");
        $data['task_search_for'] = "Replica tasks";
        $data['replica_btn'] = 1;
        $data['task_search_view'] = $this->tms_ajax->task_search();
        if (!file_exists(APPPATH . '/views/tms/user_task_manage/v_all_tasks.php')) {
            show_404();
        }
        $data['title'] = ucfirst("Upcoming Replica Task List | " . SITE_NAME); //capitalizing the first character of string for header.
        $this->load->view('tms/user_task_manage/v_all_tasks.php', $data);
        $this->load->view('templates/footer.php');
    }

    public function get_user_availability() {
        $formdata = $this->input->post();
        echo json_encode($this->m_task->get_user_availability($formdata));
    }

    public function get_task_code() {
        $formdata = $this->input->post();
        echo json_encode($this->m_task->get_task_code($formdata));
    }

    /*

     * give result of task __ calling from ajax     */

    public function get_task_result($form_data = array()) {
        if (empty($form_data)) {
            $form_data = $this->input->post();
        }
        if (isset($form_data['view_change']) && $form_data['view_change']) {
            $data['s_no'] = ($form_data['page']?$form_data['page']:0)*$form_data['limit']; 
            $data['s_no']++;
            //call the model function to get the department data
            $form_data['page'] = $form_data['page'] * $form_data['limit'];
            $data['my_tasks'] = $this->m_task->get_my_tasks($form_data); 
            echo json_encode(array("succ" => TRUE, "html" => $this->load->view('tms/manage_tasks/v_my_tasks.php', $data, TRUE)));
        } else {
            $data['s_no'] = ($form_data['page']?$form_data['page']:1)*$form_data['limit'];
            $data['s_no']++;
            $form_data['page'] = $data['s_no'] - 1;
            $data['my_tasks'] = $this->m_task->get_my_tasks($form_data);
            
//            $data['task_list'] = $this->m_task->getTasks($form_data);
            if (isset($form_data['replica_btn']) && $form_data['replica_btn'] == TRUE) {
                $data['replica_btn'] = TRUE;
            }
            echo json_encode(array("succ" => TRUE, "html" => $this->load->view('tms/manage_tasks/v_my_tasks.php', $data, TRUE)));
        }
    }

    public function my_tasks($upper_limit = 0) {
        global $data;
//        $data = $this->util_model->set_error($data, $error, $_err_codes);
        $data['incharge'] = $this->input->get("Incharge");
        $this->load->library("ajax/tms_ajax.php");
        $data['task_search_for'] = "Tasks";
        $data['view_change'] = TRUE;
        $existing_data = array("progress_flag" => 2);
        $data['task_search_view'] = $this->tms_ajax->task_search($existing_data);
        $limits = "";
        if (!is_numeric($upper_limit)) {
            $limits = array("end_limit" => 5, "start_limit" => 0);
        } else {
            $limits = array("end_limit" => 5, "start_limit" => 5 * $upper_limit);
        }
        $data['s_no'] = 5 * $upper_limit + 1;

        $data['my_tasks'] = $this->m_task->get_my_tasks($limits);

        if (!empty($data['my_tasks'])) {
            $config['total_rows'] = ceil($this->m_task->count_my_task() / 5);

            for ($i = 0, $j = 0; $i < $config['total_rows']; $i++) {
                $data['page_links'][] = "<a href=" . base_url('tms/manage_tasks/my_tasks') . "/" . $i . " >" . ++$j . "</a>";
            }
        }
//        die($this->util_model->printr($data['my_tasks']));
        if (!file_exists(APPPATH . '/views/tms/manage_tasks/v_my_tasks.php')) {
            show_404();
        }

        $this->load->view('templates/header.php', $data);
        $this->load->view('templates/common_window_pop_up.php');
//        $data['task_html'] = $this->load->view('tms/manage_tasks/v_my_tasks.php', $data, TRUE);
        $data['task_html'] = "";
        $this->load->view('tms/manage_tasks/v_template.php', $data);
        $this->load->view('templates/footer.php');
    }

    public function completed_tasks($upper_limit = 0) {
        global $data;
//        $data = $this->util_model->set_error($data, $error, $_err_codes);
        $this->load->library("ajax/tms_ajax.php");
        $data['task_search_for'] = "Tasks";
        $data['view_change'] = TRUE;
        $existing_data = array("progress_flag" => COMPLETED_APPROVAL);
        $existing_data['BillingDone'] = $this->input->get('BillingDone');
        $data['task_search_view'] = $this->tms_ajax->task_search($existing_data);
        $this->load->view('templates/header.php', $data);
        $this->load->view('templates/common_window_pop_up.php');
//        $data['task_html'] = $this->load->view('tms/manage_tasks/v_my_comp_tasks.php', $data, TRUE);
        $data['task_html'] = "";
        $this->load->view('tms/manage_tasks/v_template.php', $data);
        $this->load->view('templates/footer.php');
    }

    public function billed_tasks($upper_limit = 0) {
        global $data;
//        $data = $this->util_model->set_error($data, $error, $_err_codes);
        $this->load->library("ajax/tms_ajax.php");
        $data['task_search_for'] = "Tasks";
        $data['view_change'] = TRUE;
        $existing_data = array("progress_flag" => COMPLETED_APPROVAL, "BillingDone" => 1);
        $data['task_search_view'] = $this->tms_ajax->task_search($existing_data);
        $this->load->view('templates/header.php', $data);
        $this->load->view('templates/common_window_pop_up.php');
//        $data['task_html'] = $this->load->view('tms/manage_tasks/v_my_comp_tasks.php', $data, TRUE);
        $data['task_html'] = "";
        $this->load->view('tms/manage_tasks/v_template.php', $data);
        $this->load->view('templates/footer.php');
    }

    public function approval_tasks($upper_limit = 0) {
        global $data;
//        $data = $this->util_model->set_error($data, $error, $_err_codes);
        $this->load->library("ajax/tms_ajax.php");
        $data['task_search_for'] = "Tasks";
        $data['view_change'] = TRUE;
        $existing_data = array("progress_flag" => COMPLETED_REQUEST);
        $data['task_search_view'] = $this->tms_ajax->task_search($existing_data);
        $this->load->view('templates/header.php', $data);
        $this->load->view('templates/common_window_pop_up.php');
//        $data['task_html'] = $this->load->view('tms/manage_tasks/v_my_comp_tasks.php', $data, TRUE);
        $data['task_html'] = "";
        $this->load->view('tms/manage_tasks/v_template.php', $data);
        $this->load->view('templates/footer.php');
    }

    public function edit_task() {
        $formdata = $this->input->post();
        if ($formdata['task_id'] != "" && $this->util_model->get_a_column_value("status", DB_PREFIX . "task_mst", array("tm_id" => $formdata['task_id'])) != "") {
            echo json_encode(array("succ" => TRUE, "link" => base_url() . "tms/manage_tasks/index/" . $formdata['task_id']));
        } else {
            echo json_encode(array("succ" => FALSE, "_err_codes" => "Invalid task id passed!!"));
        }
    }

    /*

     * request to close task
     * name has been given by deepak, so I 
     * haven't changed ..      */

    public function close_task() {
        $formdata = $this->input->post();
        
        if ($formdata['task_id'] != "" && $this->util_model->get_a_column_value("status", DB_PREFIX . "task_mst", array("tm_id" => $formdata['task_id'])) != "") {
            echo json_encode($this->m_task->close_task($formdata));
            // mail to director and partner that someone request to close this task
        } else {
            echo json_encode(array("succ" => FALSE, "_err_codes" => "Invalid task passed or it already closed or deleted, ErrorCode #08092016_1226!!"));
        }
    }

    /*

     * it iwll final completed this
     * only director or patner can do this     /
     */

    public function final_close_task() {
        $formdata = $this->input->post();
        if ($formdata['task_id'] != "" && $this->util_model->get_a_column_value("status", DB_PREFIX . "task_mst", array("tm_id" => $formdata['task_id'])) != "") {
            echo json_encode($this->m_task->final_complete_task($formdata));
        } else {
            echo json_encode(array("succ" => FALSE, "_err_codes" => "Invalid task passed or it already closed or deleted, ErrorCode #08092016_1226!!"));
        }
    }

    /*

     * In case complete request discarded this function will work
     *      */

    public function reopen_task() {
        $formdata = $this->input->post();
        if ($formdata['task_id'] != "" && $this->util_model->get_a_column_value("status", DB_PREFIX . "task_mst", array("tm_id" => $formdata['task_id'])) != "") {
            echo json_encode($this->m_task->reopen_task($formdata));
        } else {
            echo json_encode(array("succ" => FALSE, "_err_codes" => "Invalid task id passed!!"));
        }
    }

    public function del_task() {
        $formdata = $this->input->post();
        if ($formdata['task_id'] != "" && $this->util_model->get_a_column_value("status", DB_PREFIX . "task_mst", array("tm_id" => $formdata['task_id'])) != "") {
            echo json_encode($this->m_task->del_task($formdata));
        } else {
            echo json_encode(array("succ" => FALSE, "_err_codes" => "Invalid task id passed!!"));
        }
    }

    public function close_sub_task() {
        $formdata = $this->input->post();
        if ($formdata['task_id'] != "" && $this->util_model->get_a_column_value("status", DB_PREFIX . "task_sub_task", array("tstm_id" => $formdata['sub_task_id'])) != "") {
            echo json_encode($this->m_task->close_sub_task($formdata));
        } else {
            echo json_encode(array("succ" => FALSE, "_err_codes" => "Invalid sub task id passed!!"));
        }
    }

    public function del_sub_task() {
        $formdata = $this->input->post();
        if ($formdata['tstm_id'] != "" && $this->util_model->get_a_column_value("status", DB_PREFIX . "task_sub_task", array("tstm_id" => $formdata['tstm_id'])) != "") {
            echo json_encode($this->m_task->del_sub_task($formdata));
        } else {
            echo json_encode(array("succ" => FALSE, "_err_codes" => "Invalid sub task id passed!!"));
        }
    }

    public function reopen_sub_task() {
        $formdata = $this->input->post();
        if ($formdata['task_id'] != "" && $this->util_model->get_a_column_value("status", DB_PREFIX . "task_mst", array("tm_id" => $formdata['task_id'])) != "") {
            echo json_encode($this->m_task->reopen_sub_task($formdata));
        } else {
            echo json_encode(array("succ" => FALSE, "_err_codes" => "Invalid task id passed!!"));
        }
    }

   
    
    
    public function reassign_sub_task_data() {
        $formdata = $this->input->post();
        echo json_encode($this->m_task->fetch_data_for_reassign_sub_task($formdata));
    }
    
    public function reassign_sub_task() {
        $formdata = $this->input->post();
        $result = $this->m_task->reassign_sub_task($formdata);
        if ($result['succ']) {
            $this->load->model("tms/m_task_log", 'm_log');
            // from free user i m not sending these two argments
            if(!isset($formdata['old_assignedto'])){
                $task_data = $this->db->get_where(DB_PREFIX."task_sub_task",array("tstm_id"=>$formdata['tstm_id']))->row_array();
                $formdata['old_assignedto'] = $task_data['assignedto'];
                $formdata['tstm_name'] = $task_data['tstm_name'];
            } 
            if(!isset($formdata['assignedto'])){
                $formdata['assignedto'] = $this->util_model->get_a_column_value("UserName",DB_PREFIX."employee",array("Emp_ID"=>$formdata['old_assignedto']));
            }
            $this->m_log->punch_log(array("log_type" => SUB_TASK_REASSIGNED, "modifier_id" => $this->util_model->get_uid(), "remarks" => "Task Reasssigned from User with user name {$formdata['old_assignedto']} to user id of user {$formdata['assignedto']}!!"));
            $filter_data = array();
            $filter_data['heading'] = array('S.no', 'Task Name', 'Incharge Name', 'Sub-task Name', 'Efforts', 'Work Date', 'Task Start Date', 'Task End Date');
            $filter_data['table_data'] = $this->m_task->info_after_reassign_for_mail_data($formdata);
            $this->load->model("tms/mail/mailer", 'mailer');

            $mailData = array();

            $mailData['to'] = $this->util_model->get_a_column_value("P_Email", DB_PREFIX . "employee", array("Emp_ID" => $formdata['new_assignedto']));
            $mailData['from'] = NOTIFY_EMAIL;
            $mailData['subject'] = "Alert for sub-task reassignment with name " . strtoupper($formdata['tstm_name']) . " by " . $this->util_model->get_uname();
            $formdata['msg'] = "Dear User," . "\n\nA  Sub-task re-assign Alert with named " . strtoupper($formdata['tstm_name']) . " has been assigned to you by " . $this->util_model->get_uname() . "!!"
                    . "<br>Find details below<br>Thanks " . EMAIL_FROM . "<br><br>" . $this->mailer->table_data($filter_data);
            $formdata['heading'] = "";

            $mailData['message'] = $this->load->view("tms/mail_template/template", $formdata, TRUE);
            $code_sent = $this->mailer->send_html($mailData);
        }
        echo json_encode($result);
    }

}
