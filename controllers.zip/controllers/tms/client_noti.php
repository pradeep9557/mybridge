<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of client_noti
 *
 * @author anup
 */
class client_noti extends CI_Controller{
    //put your code here
    public function __construct() {
        parent::__construct();
    }
    
    public function index() {
        global $data;
        $this->load->model('tms/m_manage_users');
        $data['client_list'] = $this->m_manage_users->get_all_clients();
        $this->load->view('templates/header.php', $data);
        $this->load->view("tms/client_noti/index");
        $this->load->view('templates/footer.php', $data);
        
    }
}
