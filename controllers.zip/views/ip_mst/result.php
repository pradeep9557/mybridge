<div class="table-responsive" >
    <table class="table table-bordered table-hover">
        <thead>
            <tr>
                <!--<th>S. No.</th>-->
                <th>Id</th>
                <th>System Code</th>
                <th>Requested User</th>
<!--                                <th>Approved By</th>-->
                <th>Status</th>
                <th>Add date and time</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php
            foreach ($systemCodeList as $row) {
                ?>
                <tr id = "<?php echo $row['id'] ?>">
                    <td><?php echo $row['id'] ?></td>
                    <td><?php echo $row['system_code'] ?></td>
                    <td><?php echo $row['requested_user'] ?></td>
                    <td><?php echo $row['status'] ? "Enbaled" : "Disabled" ?></td>
                    <td><?php echo $row['Add_DateTime'] ?></td>
                    <td>
                        <button data-toggle="tooltip" title="Edit" type="button" class="btn btn-<?php echo $row['status'] ? "danger" : "primary"; ?>" onclick="change_status(<?php echo $row['id'] . "," . (!$row['status']) ?>)">
                            <?php echo $row['status'] ? "Disable" : "Enable"; ?>
                        </button>

                    </td>
                </tr>


                    <!--//                                echo "<tr id=" + $row['id'] + ">"
                    //                                . "<td>" + $row['id'] + "</td>"
                    //                                . "<td>" + $row['system_code'] + "</td>"
                    //                                . "<td>" + $row['requested_row'] + "</td>"
                    //                                . "<td>" + $row['status'] + "</td>"
                    //                                . "<td>" + $row['Add_DateTime'] + "</td>"
                    //                                . "<td>"
                    //                                . "<a href=" + base_url() + "ip_mst/c_ip/index/" + $row['id'] + ">"
                    //                                . "<button data-toggle='tooltip' title='Edit' type='button' class='btn btn-success' ><i class='glyphicon glyphicon-edit'></i>"
                    //                                . "</button></a>"
                    //                                . "</td>" + " < /tr>";-->

                <?php
            }
            ?>
        </tbody>
    </table>
</div>
