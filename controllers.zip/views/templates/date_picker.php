<link rel="stylesheet" type="text/css" media="all" href="<?=base_url()?>date_range_picker/daterangepicker-bs3.css" />
      <!--<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.8.1/jquery.min.js"></script>-->
<!--      <script type="text/javascript" src="http://netdna.bootstrapcdn.com/bootstrap/3.1.1/js/bootstrap.min.js"></script>-->
      <script type="text/javascript" src="<?=base_url()?>date_range_picker/moment.js"></script>
      <script type="text/javascript" src="<?=base_url()?>date_range_picker/daterangepicker.js"></script>
      <script src="<?=base_url()?>date_range_picker/moment.min.js" type="text/javascript"></script>