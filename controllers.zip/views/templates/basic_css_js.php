<!--fonts-->
<link href='https://fonts.googleapis.com/css?family=Work+Sans' rel='stylesheet' type='text/css'>
<!--end of fonts-->
<script src="<?= base_url() ?>js/jquery-1.11.0.js" type="text/javascript"></script> 
<link href="<?= base_url() ?>css/sb-admin-2.css" rel="stylesheet" type="text/css"/>
<link rel="stylesheet" type="text/css" href="<?= base_url() ?>css/bootstrap.css">

<!-- for sweet alert -->
<link href="<?= base_url() ?>js/sweetalert/lib/sweet-alert.css" rel="stylesheet" type="text/css"/>
<script src="<?= base_url() ?>js/sweetalert/lib/sweet-alert.js" type="text/javascript"></script>
<!-- multi select -->
<link href="<?= base_url() ?>js/multi_select/chosen.css" rel="stylesheet" type="text/css"/>

<!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
<!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
    <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
<![endif]-->


<link href="<?= base_url() ?>css/custome.css" rel="stylesheet" type="text/css"/>

<!-- preloader -->
<link href="<?= base_url() ?>js/material_preloader/materialPreloader.css" rel="stylesheet" type="text/css"/>
<script src="<?= base_url() ?>js/custom_js/helper.js" type="text/javascript"></script>
<script src="<?= base_url() ?>js/material_preloader/materialPreloader.js" type="text/javascript"></script>
<script src="<?= base_url() ?>js/material_preloader/preloader_runner.js" type="text/javascript"></script>

<!-- Material preloader -->

<!-- Custom Fonts -->
<link href="<?= base_url() ?>font-awesome-4.1.0/css/font-awesome.min.css" rel="stylesheet" type="text/css">
