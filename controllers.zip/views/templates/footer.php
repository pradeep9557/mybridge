<!-- footer css-->
<link rel="stylesheet" type="text/css" href="<?= base_url() ?>css/footer.css"> 
<!--<div class="col-lg-12 footer">
    <div class="text-right">Powered by <a href="http://nexgi.com">NexGen Innovators</a></div>
</div>-->
<?php
 include_once("footer_js.php");
 ?>