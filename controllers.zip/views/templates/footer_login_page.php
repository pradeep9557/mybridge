<!-- footer css-->
<link rel="stylesheet" type="text/css" href="<?= base_url() ?>css/footer.css">
<div class="col-lg-12 footer">
    <div class="col-lg-3 hidden-xs">&nbsp;</div>
    <div class="col-lg-6 text-center">Powered by: <a target="_blank" title="NexGen Innovators IT Services Pvt Ltd" href="http://nexgeninnovators.com/">NexGen Innovators IT Services Pvt Ltd</a></div>
    <div class="col-lg-3 text-center">
    	<a title="About NexIBMS" target="_blank" href="http://nexibms.com/">About NexIBMS ...</a>
    </div>
</div>
<!--<script src="<?= base_url() ?>js/bootstrap.min.js" type="text/javascript"></script>-->
<?php
// include_once("footer_js.php");
 ?>