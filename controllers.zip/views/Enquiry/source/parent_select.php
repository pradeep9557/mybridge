<?php
    echo form_dropdown($field_name, $Parent,'',"class='form-control chosen-select'");
?>
