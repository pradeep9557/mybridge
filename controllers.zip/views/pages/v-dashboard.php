<!-- for charts --> 
<link href="<?= base_url() ?>css/plugins/morris.css" rel="stylesheet">
<script src="<?= base_url() ?>js/plugins/morris/raphael.min.js" type="text/javascript"></script>
<script src="<?= base_url() ?>js/plugins/morris/morris.min.js" type="text/javascript"></script>
<div id="page-wrapper" style="min-height: 345px;padding:0px 0px 0px 10px">
    <div class="row">
        <div class="col-lg-12">
            &nbsp;
            <!--<h1 class="page-header ">Dashboard</h1>-->
        </div>

    </div>

    <div class="row">
        <div class="col-lg-6  col-md-6 col-sm-6">
            <div class="col-md-12">
                <div class="panel panel-default">
                    <div class="panel-heading">
                        <i class="fa fa-bell fa-fw"></i> 
                        System Status
                    </div>
                    <!-- /.panel-heading -->
                    <div class="panel-body">
                        <div class="list-group">
                            <?php
//        $this->util_model->printr($all_box);
                            $i = 0;
                            foreach ($all_box as $box):
                                $box['icon'] = str_replace("fa-4x", "", $box['icon']);
                                ?>
                                <div  class="list-group-item">
                                    <i class="<?= $box['icon'] ?>"></i> &nbsp;<span class="value_text"><?= $box['value'] ?></span> <?= $box['title'] ?>
                                    <span class="pull-right text-muted small a_text_decoration"><?= $box['link_title'] ?></span>
                                    </span>
                                </div> 
                            <?php endforeach; ?>
                        </div>
                        <!-- /.list-group -->

                    </div>
                    <!-- /.panel-body -->
                </div>
            </div>
            <?php
            if (isset($client_working_status) && !empty($client_working_status['clientTaskData'])) {
                ?>
                <div class="col-lg-12">
                    <div class="panel panel-primary">
                        <div class="panel-heading">
                            <i class="fa fa-bar-chart-o fa-fw"></i> Client Wise Task Status

                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">

                            <table class="table table-bordered table-striped table-hover">
                                <thead>
                                    <tr>
                                        <td>S.No.</td>
                                        <td>Client Name</td>
                                        <td>Pending Sub task</td>
                                        <td>Total Required Time<br>/ Total Spent</td>
                                        <td>OverDue</td>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    $s_no = 1;
                                     $total['subTask'] = 0;
                                    $total['given'] = 0;
                                    $total['spent'] = 0;
                                    $total['overDue'] = 0;
                                    foreach ($client_working_status['clientTaskData'] as $row) {
                                        ?>
                                        <tr>
                                            <td><?php echo $s_no++; ?></td>
                                            <td><?php echo "<a href='".  base_url("my_sub_tasks?progress_flag=".IN_PROGRESS."&client_id={$row['client_id']}")."'>".$row['client_name']."</a>"; ?></td>
                                            <td><?php echo $row['total_pending_sub_task']; ?></td>
                                            <td><?php echo round($row['time_given'])."/".round($row['time_spent']); ?></td>
                                            <td><?php 
                                             $overDue = round($row['time_given'])<round($row['time_spent'])?round($row['time_spent']-$row['time_given'],2):0;
                                             echo $overDue!=0 ? $overDue." Hrs":"No";
                                            ?></td>
                                        </tr>
                                    <?php  $total['subTask']+=$row['total_pending_sub_task'];
                                    $total['given']+=round($row['time_given'], 2);
                                    $total['spent']+=round($row['time_spent'], 2);
                                            $total['overDue'] +=$overDue;
                                            }
                                    echo "<tr><td colspan='2'>Total</td><td>{$total['subTask']}</td><td>".round($total['given']/PER_DAY_HOURS,0)."/".round($total['spent']/PER_DAY_HOURS,0)." Days</td><td>".round($total['overDue']/PER_DAY_HOURS,0)." Days</td></tr>"; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            <?php } ?>
            
        </div> 
        <div class='col-lg-6 col-md-6'>
            <?php
//            $this->util_model->printr($team_monitering);
            if (isset($team_monitering)) {
                ?>
                <div class="col-lg-12">
                    <div class="panel panel-primary">
                        <div class="panel-heading">
                            <i class="fa fa-bar-chart-o fa-fw"></i> Only team monitoring

                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">

                            <table class="table table-bordered table-striped table-hover">
                                <thead>
                                    <tr>
                                        <td>S.No.</td>
                                        <td>Team Member</td>
                                        <td>Assigned sub task</td>
                                        <td>Total Required Time<br>/ Total Spent</td>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    $s_no = 1;
                                    $total['subTask'] = 0;
                                    $total['given'] = 0;
                                    $total['spent'] = 0;
                                    foreach ($team_monitering['team_data'] as $value) {
//                                        $this->util_model->printr($value);
                                        if ($value['assignedPer'] == "")
                                            continue;
                                        ?>
                                        <tr>
                                            <td><?php echo $s_no++; ?></td>
                                            <td><?php echo "<a href='" . base_url("my_sub_tasks?progress_flag=".IN_PROGRESS."&assignTo={$value['assignedTo']}") . "'>" . ucfirst($value['assignedPer']) . "</a>"; ?></td>
                                            <td><?php echo $value['total_subTask'] ?></td>
                                            <td><?php echo round($value['time_given'], 2) ?>/ <?php echo round($value['time_spent'], 2) ?></td>
                                        </tr>    
                                    <?php $total['subTask']+=$value['total_subTask'];
                                    $total['given']+=round($value['time_given'], 2);
                                    $total['spent']+=round($value['time_spent'], 2);
                                            }
                                    echo "<tr><td colspan='2'>Total</td><td>{$total['subTask']}</td><td>".round($total['given']/PER_DAY_HOURS,0)."/".round($total['spent']/PER_DAY_HOURS,0)." Days</td></tr>";
                                    ?>
                                        
                                </tbody>
                            </table> 
                        </div>
                    </div>
                </div>
            <?php } ?>
                 <?php
            if (isset($task_monitering) && !empty($task_monitering['TaskData'])) {
                ?>
                <div class="col-lg-12">
                    <div class="panel panel-primary">
                        <div class="panel-heading">
                            <i class="fa fa-bar-chart-o fa-fw"></i> Task Category Wise

                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">

                            <table class="table table-bordered table-striped table-hover">
                                <thead>
                                    <tr>
                                        <td>S.No.</td>
                                        <td>Task Cat</td>
                                        <td>Pending Sub task</td>
                                        <td>Total Required Time<br>/ Total Spent</td>
                                        <td>OverDue</td>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    $s_no = 1;
                                     $total['subTask'] = 0;
                                    $total['given'] = 0;
                                    $total['spent'] = 0;
                                    $total['overDue'] = 0;
                                    foreach ($task_monitering['TaskData'] as $row) {
                                        ?>
                                        <tr>
                                            <td><?php echo $s_no++; ?></td>
                                            <td><?php echo "<a href='".  base_url("my_sub_tasks?progress_flag=".IN_PROGRESS."&ttm_id={$row['ttm_id']}")."'>".$row['cat_name']."</a>"; ?></td>
                                            <td><?php echo $row['total_pending_sub_task']; ?></td>
                                            <td><?php echo round($row['time_given'])."/".round($row['time_spent']); ?></td>
                                            <td><?php 
                                             $overDue = round($row['time_given'])<round($row['time_spent'])?round($row['time_spent']-$row['time_given'],2):0;
                                             echo $overDue!=0 ? $overDue." Hrs":"No";
                                            ?></td>
                                        </tr>
                                    <?php  $total['subTask']+=$row['total_pending_sub_task'];
                                    $total['given']+=round($row['time_given'], 2);
                                    $total['spent']+=round($row['time_spent'], 2);
                                    $total['overDue'] +=$overDue;
                                            }
                                    echo "<tr><td colspan='2'>Total</td><td>{$total['subTask']}</td><td>".round($total['given']/PER_DAY_HOURS,0)."/".round($total['spent']/PER_DAY_HOURS,0)." Days</td><td>".round($total['overDue']/PER_DAY_HOURS,0)." Days</td></tr>"; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            <?php } ?>
                
                <?php if (isset($last_7_day_working_hours)): ?>
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <i class="fa fa-bar-chart-o fa-fw"></i> Last seven days working hours
                            <div class="pull-right">
                                <div class="btn-group">
                                    <a href="<?php echo $last_7_day_working_hours['link'] ?>">
                                        <button type="button" class="btn btn-default btn-xs">
                                            View More 
                                        </button> 
                                    </a>
                                </div>
                            </div>
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">
                            <div id="last_7_day_working_hours"></div>
                            <script>
                                $(function () {

                                    Morris.Line({
                                        element: 'last_7_day_working_hours',
                                        data: <?php echo json_encode($last_7_day_working_hours['json_data']); ?>,
                                        xkey: 'work_datetime',
                                        ykeys: ['efforts', 'total_working_hours'],
                                        labels: ['WorkTime in hours', 'Total Working Hours'],
                                        lineColors: ['#ff9800', '#673ab7'],
                                        pointSize: 5,
                                        hideHover: 'auto',
                                        resize: true,
                                        fillOpacity: .5,
                                        goals: [0, 300]
                                    });
                                });
                            </script>
                        </div>
                        <!-- /.panel-body -->
                    </div>
                </div>
                <?php
            endif;
            if (isset($last_7_days_entry_log)):
                ?>
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <i class="fa fa-bar-chart-o fa-fw"></i> Last seven days Working Summery
                            <div class="pull-right">
                                <div class="btn-group">
                                    <a href="<?php echo $last_7_day_working_hours['link'] ?>">
                                        <button type="button" class="btn btn-default btn-xs">
                                            View More 
                                        </button> 
                                    </a>
                                </div>
                            </div>
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">
                            <div id="last_7_days_entry_log"></div>
                            <script>
                                $(function () {

                                    Morris.Line({
                                        element: 'last_7_days_entry_log',
                                        data: <?php echo json_encode($last_7_days_entry_log['json_data']); ?>,
                                        xkey: 'work_datetime',
                                        ykeys: ['total_users', 'wrkDonePunched', 'total_entry'],
                                        labels: ['EntryDone', 'TotalUsers', 'Total Entry'],
                                        lineColors: ['#ff9800', '#673ab7', '#009688'],
                                        pointSize: 5,
                                        hideHover: 'auto',
                                        resize: true,
                                        fillOpacity: .5,
                                        goals: [0, 50]
                                    });
                                });
                            </script>
                        </div>
                        <!-- /.panel-body -->
                    </div>
                </div>
                <?php
            endif;
            if ($dashboard_weigets['this_month_follow_donut']) {
                ?>  
                <div class="col-md-12">
                    <div class="panel panel-danger">
                        <div class="panel-heading">
                            <i class="fa fa-bar-chart-o fa-fw"></i> Today's Follow ups <?= count($todays_follow_up) ?> (<?= $followed ?>/<?= $unfollowed ?>)
                        </div>

                        <div class="panel-body">


                            <?php
                            // if $todays_follow up is zero then donut will not display !!

                            if (isset($todays_follow_up)) {
                                ?>
                                <div id="morris-donut-chart" style="height: 200px"></div>
                                <script>
                                    Morris.Donut({
                                        element: 'morris-donut-chart',
                                        data: [
        <?php echo $follow_up_details ?>
                                        ],
                                        backgroundColor: '#ccc',
                                        labelColor: '#060',
                                        colors: [
                                            '#0BA462',
                                            '#39B580',
                                            '#67C69D',
                                            '#95D7BB'
                                        ],
                                        formatter: function (x) {
                                            return x + "%";
                                        }

                                    });
                                </script>
                            <?php } ?>

                            <a href="<?= base_url() ?>Enquiry/followups/follow_up_list" class="btn btn-default btn-block">View Details</a>

                        </div>
                        <!-- /.panel-body -->
                    </div>
                </div>
            <?php } ?>
            <?php
            if ($dashboard_weigets['this_month_follow_tabular']) {
                ?> 
                <div class="panel panel-info">
                    <div class="panel-heading">
                        <i class="fa fa-bar-chart-o fa-fw"></i> Today's Follow ups <?= count($todays_follow_up) ?> (<?= $followed ?>/<?= $unfollowed ?>)
                    </div>

                    <div class="panel-body">
                        <table class="table table-bordered table-hover">
                            <thead>
                                <tr>
                                    <th>S.No</th>
                                    <th>Name</th>
                                    <th>Mobile</th>
                                    <th>Follow</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $sno = 1;
                                if (!empty($todays_follow_up)) {
                                    foreach ($todays_follow_up as $each_row) {
                                        
                                    }
                                    ?>
                                    <tr>
                                        <td><?php echo $sno++; ?></td>
                                        <td><?php echo $each_row->StudentName ?></td>
                                        <td><?php echo $each_row->Mobile1 ?></td>
                                        <td><a href="<?php echo base_url() ?>Enquiry/followups/index/<?php echo $each_row->E_Code ?>" title="Follow Up" target="_blank">
                                                <button type="button" name="Follow_up" value="Follow Up" class="btn btn-info btn-xs">
                                                    <span class="glyphicon glyphicon-thumbs-up"></span>
                                                </button>
                                            </a></td>
                                    </tr>
                                <?php } else { ?>
                                    <tr>
                                        <td colspan="4">No Enquiry to Follow up</td>
                                    </tr>
                                <?php } ?>
                            </tbody>
                        </table>
                    </div>
                    <!-- /.panel-body -->
                </div>
            <?php } ?>
        </div>
    </div>
    <div class="row">
        <div class="col-lg-12 col-md-12">
            <div class="col-lg-12">
                <?php
                if ($dashboard_weigets['this_month_fee_pending']) {
                    ?>
                    <div class="panel panel-danger">
                        <div class="panel-heading">
                            <i class="fa fa-calendar fa-fw"></i> Total Pending Installments <?= count($pending_fees) ?>
                        </div>


                        <div class="panel-body">
                            <table class="table table-bordered table-hover">
                                <thead>
                                    <tr>
                                        <th>S.No</th>
                                        <th>Student Name</th>
                                        <th>Enroll No</th>
                                        <th>Mobile</th>
                                        <th>Due Date</th>
                                        <th>Due Amount</th>
                                        <th>Net Payable</th>
                                        <th>Paid</th>
                                        <th>Balance</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    $sno = 1;
                                    if (count($pending_fees)) {
                                        foreach ($pending_fees as $each_row) {
                                            ?>
                                            <tr>
                                                <td><?php echo $sno++; ?></td>
                                                <td><?php echo $each_row['StudentName'] ?></td>
                                                <td><?php echo $each_row['EnrollNo'] ?></td>
                                                <td><?php echo $each_row['Mobile1'] ?></td>
                                                <td><?php echo $each_row['due_date'] ?></td>
                                                <td><?php echo $each_row['DueInstAmt'] ?></td>
                                                <td><?php echo $each_row['NetPayableAmt'] ?></td>
                                                <td><?php echo $each_row['PaidAmt'] ?></td>
                                                <td><?php echo $each_row['BalanceAmt'] ?></td>

                                            </tr>
                                            <?php
                                        }
                                        ?>

                                    <?php } else { ?>
                                        <tr>
                                            <td colspan="4">No any pending installment</td> 
                                        </tr>
                                    <?php } ?>
                                </tbody>
                            </table>
                        </div>
                        <!-- /.panel-body -->
                    </div>
                <?php } ?>
            </div>
        </div>
    </div>


</div>