<?php
    echo form_dropdown($field_name, $list,$selected,"class='form-control chosen-select'");
?>
