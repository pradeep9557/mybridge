<div class="panel panel-primary">
    <div class="panel-heading" data-toggle="collapse" data-target="#collapseExample">
        <h3 class="panel-title toggle_custom">My Task Detail<span class="glyphicon glyphicon-chevron-down glyphicon-chevron-up pull-right" ></span></h3>
        <?php
//          echo $pagination;
        ?>
    </div>
    <div class="panel-body collapse in" id="collapseExample">   
        <?php
//        $this->util_model->printr($my_tasks);
        if (empty($my_tasks)) {
            echo "No More Tasks Found!!";
        } else {
            
            $i = $s_no;
            foreach ($my_tasks as $value) {
//                $this->util_model->printr($value);
//                die();
                ?>
                <table class="table table-bordered">
                    <tr>
                        <th style="font-weight: bold;" colspan="8" class="text-center"><?php echo "#Task Name: {$value['tm_name']}({$value['tm_code']})"; ?> </th>
                    </tr>
                    <tr>
                        <th>S.no</th>
                        <th>Task Category</th>
                        <th>Task Type</th>
                        <?php
                        if ($value['billedFrom'] != ''  && $this->util_model->get_authStatus('manage_bills','print_bill')) {
                            echo "<th><b class='text-success'>BilledFrom</b></th>";
                        }
                        ?>
                        <th>Total Sub Tasks</th>
                        <th>Client Name</th>
                        <th>In charge</th>
                        <th>Progress/Completion</th>
                        <th>Target Date</th>
                        <th style="width: 100px;">Action</th>
                    </tr>
                    <tr class="<?php //echo $value['progress_flag'] == COMPLETED_APPROVAL ? "strikeout" : ""     ?>">
                        <td><?= $i++; ?></td>
                        <td><?php echo $value['skill_dev_activity']?"Skill Development":"Other" ?></td>
                        <td><a href="<?php echo base_url("tms/manage_task_logs/index/" . $value['tm_id']); ?>" title="click here to get task history"><?= $value['ttm_name'] . "(:{$value['tm_id']})"; ?></a></td>
                        <?php
                        if ($value['billedFrom'] != '' && $this->util_model->get_authStatus('manage_bills','print_bill')) {
                            echo "<td><b class='text-success'>{$value['billedFrom']}</b><br><a href='" . base_url("tms/manage_bills/print_bill/{$value['bill_mst_id']}") . "'>PrintBill</a></td>";
                        }
                        ?>
                        <td><?= $value['total_sub_task'] ?></td>

                        <td><?= $value['client_name'] ?></td>
                        <td><?= $value['Incharge_name'] ?></td>
                        <td><?php echo $this->util_model->get_progress_flag_string($value['progress_flag']);
                        if($value['progress_flag']==COMPLETED_APPROVAL){
                            echo "<br><strong> at ".date(DF,  strtotime($value['Mode_DateTime']))."</strong> with comments <br> <strong>{$value['close_task_note']}</strong>";
                        }
                        ?></td>
                        <td><?= date(DF, strtotime($value['end_date'])) ?></td>
                        <td><?php
                            if (isset($_POST['does_repeat']) && $_POST['does_repeat']) {
                                ?>
                                <a target="_blank" href="<?php echo base_url() . "tms/manage_tasks/index/" . $value['tm_id'] . "?tab=create_replica" ?>" title="Create Replica or repeat this task"  class="btn btn-danger btn-xs" >
                                    <span class="glyphicon glyphicon-repeat"></span> 
                                </a>
                            <?php
                            }
                            if ($value['progress_flag'] != COMPLETED_REQUEST && $value['progress_flag'] != COMPLETED_APPROVAL) {
                                ?>
                                <a target="_blank" href="<?php echo base_url() . "tms/manage_tasks/index/" . $value['tm_id'] ?>" title="Edit Task"  class="btn btn-danger btn-xs" >
                                    <span class="glyphicon glyphicon-edit"></span> 
                                </a>
                                <a target="_blank" href="<?php echo base_url() . "tms/manage_tasks/index/" . $value['tm_id'] . "?tab=copy_task" ?>" title="Copy Task"  class="btn btn-danger btn-xs" >
                                    <span class="glyphicon glyphicon-file"></span> 
                                </a>
                                <button key="<?= $value['tm_id'] ?>" title="Request to close task" type="button"  class="btn btn-danger btn-xs <?php echo $value['progress_flag'] == COMPLETED_REQUEST ? "" : "close_task" ?>" >
                                    <span class="glyphicon glyphicon-send"></span> 
                                </button>
                                <?php
                            }
                            if (in_array($this->util_model->get_utype(), array(DIRECTOR, PARTNER))) {
                                ?>
                                <button key="<?php echo $value['tm_id'] ?>" type="button"  class="del_task btn btn-xs btn-primary"><span class="glyphicon glyphicon-trash" title="Delete Task"></span>
                                </button>
                                <?php if ($value['progress_flag'] == COMPLETED_REQUEST || $value['progress_flag'] == COMPLETED_APPROVAL) { ?> 
                                    <button key="<?php echo $value['tm_id'] ?>" type="button"  class="reopen_task btn btn-xs btn-primary"><span class="fa fa-level-up" title="Reopen Task"></span>
                                    </button>

                                    <?php
                                }
                                if ($value['progress_flag'] == COMPLETED_REQUEST) {
                                    ?> 
                                    <button key="<?php echo $value['tm_id'] ?>" type="button" req_msg ="<?php echo $value['close_task_note']; ?>"  class="final_close_task btn btn-xs btn-danger"><span class="fa fa-check" title="Final close this Task"></span>
                                    </button>
                                    <a href="<?php echo base_url("tms/manage_bills/index/") . $value['tm_id']; ?>"  target="_blank"  class="hide gen_bill">
                                        <button key="<?php echo $value['tm_id'] ?>" type="button" class="btn btn-xs btn-info"><span class="fa fa-send-o" title="Generate Bill"></span>
                                        </button>
                                    </a>

                                    <?php
                                }
                                if ($value['progress_flag'] == COMPLETED_APPROVAL && $value['BillingDone'] == 0) {
                                    ?> 

                                    <a href="<?php echo base_url("tms/manage_bills/index/?tm_id=" . $value['tm_id']); ?>" class="gen_bill" target="_blank" >
                                        <button key="<?php echo $value['tm_id'] ?>" type="button"  class="btn btn-xs btn-info"><span class="fa fa-send-o" title="Generate Bill"></span>
                                        </button>
                                    </a>

                                    <?php
                                }
//                                else{
//                                      echo $value['billedFrom'];
//                                }
                            }
                            ?>
                        </td>
                    </tr>
                    <tr>
                        <th colspan="8" style="text-align: center;font-weight: bold;">Remarks</th>
                    </tr>
                    <tr  class="<?php //echo $value['progress_flag'] == COMPLETED_APPROVAL ? "strikeout" : ""    ?>">
                        <td></td>
                        <td style="font-style: italic;" colspan="5">
                            <?php echo $value['extra_note'] ?>
                        </td>
                        <td></td>
                    </tr>
                    <tr>
                        <td></td>
                        <td colspan="7">
                            <table class="table sub_task_table">
                                <tr class="sub_header">
                                    <th style="text-align: center;font-weight: bold;" colspan="7">Sub Tasks
                                        <span key="0" class="hide_show_sub_task">Show Sub Task Details</span>
                                    </th>
                                </tr>
                                <tr style="display: none">
                                    <th>S.no</th>
                                    <th>Sub Task Name</th>
                                    <th>Assigned to</th>
                                    <th>Progress/Completion</th>
                                    <th>Start Date</th>
                                    <th>End Date</th>
                                    <th style="width: 70px;">Action</th>
                                </tr>
                                <?php
                                $j = 1;
                                foreach ($value['sub_task_data'] as $sub_task) {
                                    ?>
                                    <tr style="display: none" class="<?php //echo $sub_task['progress_flag'] == COMPLETED_REQUEST ? "strikeout" : ""    ?>">
                                        <td><?= $j++ ?></td>
                                        <td><a href="<?php echo base_url("tms/manage_sub_task/taskSingleView/" . $sub_task['tstm_id']); ?>" target="_blank"><?= $sub_task['tstm_name'] . "(ID:{$sub_task['tstm_id']})" ?></a></td>
                                        <td class="sub_task_assigned_to"><?= $sub_task['Emp_Name'] ?></td>
                                        <td class="progress_flag"><?php echo $this->util_model->get_progress_flag_string($sub_task['progress_flag']); ?></td>
                                        <td><?php echo date("F j, Y, g:i a", strtotime($sub_task['str_date_time'])) ?></td>
                                        <td><?php echo date("F j, Y, g:i a", strtotime($sub_task['end_date_time'])) ?></td>
                                        <td>
                                            <?php
                                            if ($value['progress_flag'] == COMPLETED_APPROVAL || $value['progress_flag'] == COMPLETED_REQUEST) {
                                                ?>
                                                <button task_id="<?= $value['tm_id'] ?>" key="<?= $sub_task['tstm_id'] ?>" title="Close Sub Task" type="button"  class="btn btn-danger btn-xs <?php echo $sub_task['progress_flag'] == COMPLETED_REQUEST ? "" : "close_sub_task" ?>" >
                                                    <span class="glyphicon glyphicon-remove"></span> 
                                                </button>
                                                <button key="<?= $sub_task['tstm_id'] ?>" data-toggle="modal" data-target="#myModal" title="Reassign Task" type="button"  class="btn btn-danger btn-xs <?php echo $sub_task['progress_flag'] == COMPLETED_REQUEST ? "" : "reassign_task" ?>" >
                                                    <span class="glyphicon glyphicon-refresh"></span> 
                                                </button>
                                            <?php } ?>

                                        </td>
                                    </tr>
                                <?php }
                                ?>
                            </table>
                        </td>
                    </tr>
                </table>
            <?php }
            ?>
            <div class="col-lg-12 pagination_links">
                <?php
                if (isset($page_links)) {
                    foreach ($page_links as $value) {
                        echo "&nbsp;" . $value;
                    }
                }
                ?>
            </div>
        <?php } ?>
    </div>
</div>

