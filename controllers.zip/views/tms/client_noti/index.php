<div id="page-wrapper" style="min-height: 345px;">
    <div class="row">
        <div class="col-lg-12">
            <h4 class="page-header ">Un-assigned Client Data</h4>
            <?php
            if (isset($error)) {
                $this->util_model->result_e_code($error, SUCCESS_MSG, $err_codes);
            }
            ?>
        </div>
        <!-- /.col-lg-12 -->
    </div>

    <div class="row bottom_gap">

        <div class="col-md-12">
            <label>Select Client</label>
            <?php echo form_dropdown('client_id', $client_list, '', "class='form-control'"); ?>
        </div>

    </div>
    <?php for($count =1;$count < 4; $count++){ ?>
    <div class="row bottom_gap">
        <div class="col-lg-12">
            <h4>Info For Level <?php echo $count;  ?></h4>
        </div>
    </div>
    <div class="row bottom_gap">
        <div class="col-lg-4 col-md-6 col-sm-12">
            <div class="form-group">
                <label>Name</label>
                <input type="text" placeholder="name" class="form-control">
            </div>
        </div>
        <div class="col-lg-4 col-md-6 col-sm-12">
            <div class="form-group">
                <label>Mobile</label>
                <input type="text" placeholder="Mobile" class="form-control">
            </div>
        </div> 
        <div class="col-lg-4 col-md-6 col-sm-12">
            <div class="form-group">
                <label>Month Day to notify if data isn't received</label>
                <select class="form-control">
                    <option>1</option>
                    <option>2</option>
                </select>
            </div>
        </div> 
    </div> <!--End of row-->
    <div class="row bottom_gap">
         <div class="col-lg-12 col-md-12 col-sm-12">
            <div class="form-group">
                <label>Message</label>
                <textarea class="form-control"></textarea>
            </div>
        </div>
    </div>
    <?php } ?>
</div>