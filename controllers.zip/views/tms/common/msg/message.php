<div class="row">
    <div class="col-lg-12">
        <?php
        if(isset($message))
        {
            echo $message['msg'];
        }
        
        ?>
    </div>
    
</div>
