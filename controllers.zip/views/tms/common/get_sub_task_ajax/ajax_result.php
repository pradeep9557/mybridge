<div class="row">  <div class="col-lg-12">
        <h5> Search Result</h5>
        <hr>
    </div>

    <div class="col-lg-12">

        <div class="table-responsive">
            <table class="responsive table table-striped table-bordered table-hover capitalized_word" id="ajax_task_list">
                <thead>
                    <tr>
                        <th>S.No</th>
                        <th>Client Name</th>
                        <th>Task Name</th> 
                        <th>Sub Task Name</th> 
                        <th>In-Charge Name</th>
                        <th>Assigned To</th>
                        <th>Work Status</th>
                        <th>Progress</th>
                        <th>Start date</th> 
                        <th>End date</th>
                        <th style="width: 70px;">Action</th>
<!--<th>Last Modified</th>-->
                    </tr>
                </thead>
                <tbody>
                    <?php
                   
                    foreach ($task_list as $each_task) {
//                        $this->util_model->printr($each_task);
                        ?>
                        <tr class="odd gradeX">
                            <td><?= ++$s_no ?></td>
                            <td><?= $each_task['client_name'] ?></td>
                            <td><?php echo $each_task['tm_name']; ?></td>
                            <td class="single_task">
                                <a target="_blank" href="<?php echo base_url() . "tms/manage_sub_task/taskSingleView/" . $each_task['tstm_id'] ?>">
                                    <?php echo $each_task['tstm_name']."({$each_task['tstm_id']}))" ?>
                                </a>
                            </td>
                            <td><?= $each_task['incharge_name'] ?></td>
                            <td class="sub_task_assigned_to"><?= $each_task['Emp_Name'] ?></td>
                            <th><?= $this->util_model->get_progress_flag_string($each_task['progress_flag']) ?></th>
                            <td><?php echo $each_task['completed'] != "" ? $each_task['completed'] : "0" ?><span>%</span></td>
                            <td><?php echo date(DF, strtotime($each_task['str_date_time'])); ?></td>
                            <td><?php echo date(DF, strtotime($each_task['end_date_time'])); ?></td>
                            <td>
                                <button key="<?= $each_task['tstm_id'] ?>" data-toggle="modal" data-target="#myModal" title="Reassign Task" type="button"  class="btn btn-danger btn-xs reassign_task" >
                                    <span class="glyphicon glyphicon-refresh"></span> 
                                </button>
                                <button key="<?= $each_task['tstm_id'] ?>"  title="Mark completed and close sub task" type="button"  class="btn btn-success btn-xs close_sub_task" >
                                    <span class="glyphicon glyphicon-check"></span> 
                                </button>
                                <?php
                                if (in_array($this->util_model->get_utype(), array(DIRECTOR, PARTNER))) {
                                    ?>
                                    <button key="<?php echo $each_task['tstm_id'] ?>" type="button"  class="del_sub_task btn btn-xs btn-primary"><span class="glyphicon glyphicon-trash" title="Delete Task"></span></button>
                                <?php }
                                ?> 

                            </td>
                        </tr>
                        <?php
                    }
                    ?>
                </tbody>
            </table>
        </div>

    </div>
    <!-- /.panel-body -->
</div>
<!-- /.panel -->
