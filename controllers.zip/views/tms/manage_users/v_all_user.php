<div class="row">
    <div class="col-lg-12">
        <h4 class="page-header">All <?php echo $caller == USER ? "Users" : "Clients" ?></h4>
    </div>
    <!-- /.col-lg-12 -->
</div>
<!-- /.row -->
<div class="row">
    <div class="col-lg-12">
        <div class="panel panel-primary">
            <div class="panel-heading"  data-toggle="collapse" data-target="#allemployee">
                <h3 class="panel-title toggle_custom"><?php echo $caller == USER ? "User" : "Client" ?> List With Advance Filter <span class="glyphicon  glyphicon-chevron-up pull-right" ></span></h3>
            </div>
            <!-- /.panel-heading -->
            <div class="panel-body" id="allemployee">
                <div class="table-responsive">
                    <table class="responsive table table-striped table-bordered table-hover capitalized_word" id="dataTables-example">
                        <thead>
                            <tr>
                                <th>S.No</th> 
                                <th>Name</th>
                                <th>Username</th>
                                <?php if ($this->util_model->get_utype() == PARTNER || $this->util_model->get_utype() == DIRECTOR) { ?>
                                    <th>Password</th>
                                <?php }
                                ?>
                                <th>User Type</th>
                                <th>Status</th>
                                <th>Add User</th>
                                <th>Modified</th>
                                <th>Edit</th> 
                            </tr> 
                        </thead>
                        <tbody>
                            <?php
                            $i = 0;
//                            $this->util_model->printr($all_emp_details);
                            foreach ($all_emp_details as $Emp_List) {
                                if ($Emp_List->UTID != 10) {
                                    ?>
                                    <tr class="odd gradeX">
                                        <td><?= ++$i ?></td>

                                        <td><?= $Emp_List->Emp_Name ?></td>
                                        <td><?= $Emp_List->UserName ?></td>
                                        <?php if ($this->util_model->get_utype() == PARTNER || $this->util_model->get_utype() == DIRECTOR) { ?>
                                            <th title="Click to toggle Password">
                                                <input type="password" value="<?php echo $this->util_model->decrypt_string($Emp_List->Emp_Pass) ?>" class="toggle_pass" readonly/>
                                            </th>   
                                        <?php }
                                        ?>
                                        <td><?= $Emp_List->UserTypeName ?></td>
                                        <td><?= $Emp_List->Status?"Enable":"Disable" ?></td>
                                        <td><?= $Emp_List->Add_UserCode ?></td>
                                        <td><?php echo date(DF, strtotime($Emp_List->Mode_DateTime)); ?></td>
                                        <td><form>
                                                <a href="<?= base_url() ?>tms/manage_users/<?php echo $addr . "/" . $Emp_List->Emp_ID ?>"><button type="button" name="Edit_Employee" title="Edit Basic Details" value="Edit" class="btn btn-success btn-xs">
                                                        <span class="glyphicon glyphicon-edit"></span> 
                                                    </button>
                                                </a>
        <!--                                                <a href="<?= base_url() ?>employee/document_attach/<?= $Emp_List->UserName ?>" title="Edit or View Documents and other details" target="_blank">
                                                    <button type="button" name="Edit_Employee" value="Edit" class="btn btn-info btn-xs">
                                                        <span class="glyphicon glyphicon-paperclip"></span>
                                                    </button>
                                                </a>-->
                                                <input type="hidden" name="_key" value="del_Emp_Code"/>
                                                <input type="hidden" name="_title"  value="<?php echo $caller == USER ? "User" : "Client" ?>"/>
                                                <input  type="hidden" value="You want to delete <?= mysql_real_escape_string($Emp_List->UserName) ?> <?php echo $caller == USER ? "User" : "Client" ?> ?? All the details related to this user will be deleted!!" name="_msg"/>
                                                <input type="hidden" value="<?= $Emp_List->UserName ?>" name="UserName"/>
                                                <button type="button"  value="Del" class="btn btn-danger btn-xs ajax_submit" >
                                                    <span class="glyphicon glyphicon-trash"></span> 
                                                </button>
                                            </form>
                                        </td>

                                    </tr>
                                    <?php
                                }
                            }
                            ?>


                        </tbody>
                    </table>
                </div>

            </div>
            <!-- /.panel-body -->
        </div>
        <!-- /.panel -->
    </div>
    <!-- /.col-lg-12 -->
</div>
<!-- Page-Level Demo Scripts - Tables - Use for reference -->
<!--<link href="<?= base_url() ?>css/plugins/dataTables.bootstrap.css" rel="stylesheet" type="text/css"/>-->
<script src="<?= base_url() ?>js/plugins/dataTables/jquery.dataTables.js"></script>
<script src="<?= base_url() ?>js/plugins/dataTables/dataTables.bootstrap.js"></script>
<!--<script src="<?= base_url() ?>js/plugins/dataTables/dataTables.responsive.min.js" type="text/javascript"></script>-->
<script>
    $(document).ready(function () {
        $('#dataTables-example').DataTable({
            responsive: true
        });
    });

    $(".toggle_pass").on("click", function () {
        $(this).attr("type", "text");
    });
</script>
