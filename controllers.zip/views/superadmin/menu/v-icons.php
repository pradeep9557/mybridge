<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


?>
<style>
   .icon_div {
          height: 70px;
  font-size: 43px;
  background: white;
  padding: 5px;
  text-align: center;
  border: thin solid;
  color: rgb(36, 63, 80);
  cursor: pointer;
    }
</style>
<h2>Choose Your Icon</h2>
<div class="col-lg-12">
    <div class="col-lg-1 col-md-1 col-sm-2 col-xs-4 icon_div" >
        <span class="glyphicon glyphicon-edit"></span>
    </div>
    <div class="col-lg-1 col-md-1 col-sm-2 col-xs-4 icon_div" >
        <span class="glyphicon glyphicon-print"></span>
    </div>
    <div class="col-lg-1 col-md-1 col-sm-2 col-xs-4 icon_div" >
         <span class="glyphicon glyphicon-list"></span>
    </div>
     <div class="col-lg-1 col-md-1 col-sm-2 col-xs-4 icon_div" >
         <span class="glyphicon glyphicon-refresh"></span>
    </div>
    <div class="col-lg-1 col-md-1 col-sm-2 col-xs-4 icon_div">
        <span class="glyphicon glyphicon-adjust"></span>
    </div>
     <div class="col-lg-1 col-md-1 col-sm-2 col-xs-4 icon_div" >
         <span class="glyphicon glyphicon-align-center"></span>
     </div>
    <div class="col-lg-1 col-md-1 col-sm-2 col-xs-4 icon_div" >
                  <span class="glyphicon glyphicon-sunglasses"></span>
    </div>
    
<div class="col-lg-1 col-md-1 col-sm-2 col-xs-4 icon_div" >
    <span class="glyphicon glyphicon-arrow-down"></span>
     </div>
<div class="col-lg-1 col-md-1 col-sm-2 col-xs-4 icon_div" >
    <span class="glyphicon glyphicon-backward"></span>
     </div>
<div class="col-lg-1 col-md-1 col-sm-2 col-xs-4 icon_div" >
    <span class="glyphicon glyphicon-ban-circle"></span>
     </div>
<div class="col-lg-1 col-md-1 col-sm-2 col-xs-4 icon_div" >
    <span class="glyphicon glyphicon-barcode"></span>
     </div>
<div class="col-lg-1 col-md-1 col-sm-2 col-xs-4 icon_div" >
    <span class="glyphicon glyphicon-bell"></span>
     </div>
<div class="col-lg-1 col-md-1 col-sm-2 col-xs-4 icon_div" >
    <span class="glyphicon glyphicon-bold"></span>
     </div>
<div class="col-lg-1 col-md-1 col-sm-2 col-xs-4 icon_div" >
    <span class="glyphicon glyphicon-book"></span>
     </div>
<div class="col-lg-1 col-md-1 col-sm-2 col-xs-4 icon_div" >
    <span class="glyphicon glyphicon-bookmark"></span>
     </div>
<div class="col-lg-1 col-md-1 col-sm-2 col-xs-4 icon_div" >
    <span class="glyphicon glyphicon-briefcase"></span>
     </div>
<div class="col-lg-1 col-md-1 col-sm-2 col-xs-4 icon_div" >
    <span class="glyphicon glyphicon-bullhorn"></span>
     </div>
<div class="col-lg-1 col-md-1 col-sm-2 col-xs-4 icon_div" >
    <span class="glyphicon glyphicon-calendar"></span>
     </div>
<div class="col-lg-1 col-md-1 col-sm-2 col-xs-4 icon_div" >
    <span class="glyphicon glyphicon-camera"></span>
     </div>
<div class="col-lg-1 col-md-1 col-sm-2 col-xs-4 icon_div" >
    <span class="glyphicon glyphicon-certificate"></span>
     </div>
<div class="col-lg-1 col-md-1 col-sm-2 col-xs-4 icon_div" >
    <span class="glyphicon glyphicon-check"></span>
     </div>
<div class="col-lg-1 col-md-1 col-sm-2 col-xs-4 icon_div" >
    <span class="glyphicon glyphicon-chevron-down"></span>
     </div>
<div class="col-lg-1 col-md-1 col-sm-2 col-xs-4 icon_div" >
    <span class="glyphicon glyphicon-chevron-left"></span>
     </div>
<div class="col-lg-1 col-md-1 col-sm-2 col-xs-4 icon_div" >
    <span class="glyphicon glyphicon-chevron-right"></span>
     </div>
<div class="col-lg-1 col-md-1 col-sm-2 col-xs-4 icon_div" >
    <span class="glyphicon glyphicon-chevron-up"></span>
     </div>
<div class="col-lg-1 col-md-1 col-sm-2 col-xs-4 icon_div" >
    <span class="glyphicon glyphicon-circle-arrow-down"></span>
     </div>
<div class="col-lg-1 col-md-1 col-sm-2 col-xs-4 icon_div" >
    <span class="glyphicon glyphicon-circle-arrow-left"></span>
     </div>
<div class="col-lg-1 col-md-1 col-sm-2 col-xs-4 icon_div" >
    <span class="glyphicon glyphicon-circle-arrow-right"></span>
     </div>
<div class="col-lg-1 col-md-1 col-sm-2 col-xs-4 icon_div" >
    <span class="glyphicon glyphicon-circle-arrow-up"></span>
     </div>
<div class="col-lg-1 col-md-1 col-sm-2 col-xs-4 icon_div" >
    <span class="glyphicon glyphicon-cloud-download"></span>
     </div>
<div class="col-lg-1 col-md-1 col-sm-2 col-xs-4 icon_div" >
    <span class="glyphicon glyphicon-cloud-upload"></span>
     </div>
        
<div class="col-lg-1 col-md-1 col-sm-2 col-xs-4 icon_div" >
    <span class="glyphicon glyphicon-cloud"></span>
     </div>
<div class="col-lg-1 col-md-1 col-sm-2 col-xs-4 icon_div" >
    <span class="glyphicon glyphicon-cog"></span>
     </div>
<div class="col-lg-1 col-md-1 col-sm-2 col-xs-4 icon_div" >
    <span class="glyphicon glyphicon-collapse-down"></span>
     </div>
<div class="col-lg-1 col-md-1 col-sm-2 col-xs-4 icon_div" >
    <span class="glyphicon glyphicon-collapse-up"></span>
     </div>
<div class="col-lg-1 col-md-1 col-sm-2 col-xs-4 icon_div" >
    <span class="glyphicon glyphicon-comment"></span>
     </div>
<div class="col-lg-1 col-md-1 col-sm-2 col-xs-4 icon_div" >
    <span class="glyphicon glyphicon-compressed"></span>
     </div>
<div class="col-lg-1 col-md-1 col-sm-2 col-xs-4 icon_div" >
    <span class="glyphicon glyphicon-copyright-mark"></span>
     </div>
<div class="col-lg-1 col-md-1 col-sm-2 col-xs-4 icon_div" >
    <span class="glyphicon glyphicon-credit-card"></span>
     </div>
<div class="col-lg-1 col-md-1 col-sm-2 col-xs-4 icon_div" >
        
     </div>
<div class="col-lg-1 col-md-1 col-sm-2 col-xs-4 icon_div" >
    <span class="glyphicon glyphicon-cutlery"></span>
     </div>
<div class="col-lg-1 col-md-1 col-sm-2 col-xs-4 icon_div" >
    <span class="glyphicon glyphicon-dashboard"></span>
     </div>
<div class="col-lg-1 col-md-1 col-sm-2 col-xs-4 icon_div" >
    <span class="glyphicon glyphicon-download-alt"></span>
     </div>
<div class="col-lg-1 col-md-1 col-sm-2 col-xs-4 icon_div" >
    <span class="glyphicon glyphicon-download"></span>
     </div>
<div class="col-lg-1 col-md-1 col-sm-2 col-xs-4 icon_div" >
    <span class="glyphicon glyphicon-earphone"></span>
     </div>
<div class="col-lg-1 col-md-1 col-sm-2 col-xs-4 icon_div" >
    <span class="glyphicon glyphicon-edit"></span>
     </div>
<div class="col-lg-1 col-md-1 col-sm-2 col-xs-4 icon_div" >
    <span class="glyphicon glyphicon-eject"></span>
     </div>

        
<div class="col-lg-1 col-md-1 col-sm-2 col-xs-4 icon_div" >
    <span class="glyphicon glyphicon-envelope"></span>
     </div>
<div class="col-lg-1 col-md-1 col-sm-2 col-xs-4 icon_div" >
    <span class="glyphicon glyphicon-euro"></span>
     </div>
<div class="col-lg-1 col-md-1 col-sm-2 col-xs-4 icon_div" >
    <span class="glyphicon glyphicon-exclamation-sign"></span>
     </div>
<div class="col-lg-1 col-md-1 col-sm-2 col-xs-4 icon_div" >
    <span class="glyphicon glyphicon-expand"></span>
     </div>
<div class="col-lg-1 col-md-1 col-sm-2 col-xs-4 icon_div" >
    <span class="glyphicon glyphicon-eye-close"></span>
     </div>
<div class="col-lg-1 col-md-1 col-sm-2 col-xs-4 icon_div" >
    <span class="glyphicon glyphicon-export"></span>
     </div>
<div class="col-lg-1 col-md-1 col-sm-2 col-xs-4 icon_div" >
    <span class="glyphicon glyphicon-eye-close"></span>
     </div>
<div class="col-lg-1 col-md-1 col-sm-2 col-xs-4 icon_div" >
    <span class="glyphicon glyphicon-eye-open"></span>
     </div>
<div class="col-lg-1 col-md-1 col-sm-2 col-xs-4 icon_div" >
    <span class="glyphicon glyphicon-facetime-video"></span>
     </div>
<div class="col-lg-1 col-md-1 col-sm-2 col-xs-4 icon_div" >
    <span class="glyphicon glyphicon-fast-backward"></span>
     </div>
<div class="col-lg-1 col-md-1 col-sm-2 col-xs-4 icon_div" >
    <span class="glyphicon glyphicon-fast-forward"></span>
     </div>
<div class="col-lg-1 col-md-1 col-sm-2 col-xs-4 icon_div" >
    <span class="glyphicon glyphicon-file"></span>
     </div>
<div class="col-lg-1 col-md-1 col-sm-2 col-xs-4 icon_div" >
    <span class="glyphicon glyphicon-film"></span>
     </div>
<div class="col-lg-1 col-md-1 col-sm-2 col-xs-4 icon_div" >
    <span class="glyphicon glyphicon-filter"></span>
     </div>
<div class="col-lg-1 col-md-1 col-sm-2 col-xs-4 icon_div" >
    <span class="glyphicon glyphicon-fire"></span>
     </div>
<div class="col-lg-1 col-md-1 col-sm-2 col-xs-4 icon_div" >
    <span class="glyphicon glyphicon-flag"></span>
     </div>
<div class="col-lg-1 col-md-1 col-sm-2 col-xs-4 icon_div" >
    <span class="glyphicon glyphicon-flash"></span>
     </div>
<div class="col-lg-1 col-md-1 col-sm-2 col-xs-4 icon_div" >
    <span class="glyphicon glyphicon-floppy-disk"></span>
     </div>
<div class="col-lg-1 col-md-1 col-sm-2 col-xs-4 icon_div" >
    <span class="glyphicon glyphicon-floppy-open"></span>
     </div>
<div class="col-lg-1 col-md-1 col-sm-2 col-xs-4 icon_div" >
    <span class="glyphicon glyphicon-floppy-remove"></span>
     </div>
<div class="col-lg-1 col-md-1 col-sm-2 col-xs-4 icon_div" >
    <span class="glyphicon glyphicon-floppy-save"></span>
     </div>
<div class="col-lg-1 col-md-1 col-sm-2 col-xs-4 icon_div" >
    <span class="glyphicon glyphicon-floppy-saved"></span>
     </div>
<div class="col-lg-1 col-md-1 col-sm-2 col-xs-4 icon_div" >
    <span class="glyphicon glyphicon-folder-close"></span>
     </div>
    
    
    
</div>
