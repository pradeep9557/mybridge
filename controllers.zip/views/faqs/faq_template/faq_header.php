<!doctype html>
<html lang="en" class="no-js">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link href='http://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700' rel='stylesheet' type='text/css'>
        <link href="<?php echo base_url()?>css/faq_template/css/reset.css" rel="stylesheet" type="text/css"/>
        <link href="<?php echo base_url()?>css/faq_template/css/style.css" rel="stylesheet" type="text/css"/>
        <title>NexGen Institute Business Management System | NexIBMS</title>
    </head>
    <body>