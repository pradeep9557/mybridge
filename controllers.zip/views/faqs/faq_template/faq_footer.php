</body>
</html>
<script src="<?php echo base_url() ?>css/faq_template/js/jquery-2.1.1.js" type="text/javascript"></script>
<script src="<?php echo base_url() ?>css/faq_template/js/modernizr.js" type="text/javascript"></script>
<script src="<?php echo base_url() ?>css/faq_template/js/main.js" type="text/javascript"></script>
<script src="<?php echo base_url() ?>css/faq_template/js/jquery.mobile.custom.min.js" type="text/javascript"></script>