<!-- no use right now -->

<div id="page-wrapper">
    <div class="row">

        <div class="col-lg-12">
            <h4 class="page-header">All Admissions</h4>
            <?php
            echo $adm_search_template;
            ?>
        </div>
    </div>
</div>
            


<script src="<?= base_url() ?>js/plugins/dataTables/jquery.dataTables.js"></script>
<script src="<?= base_url() ?>js/plugins/dataTables/dataTables.bootstrap.js"></script>